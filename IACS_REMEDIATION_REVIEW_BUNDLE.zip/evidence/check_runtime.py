import json, subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
run=next((base/'runtime-accepted').glob('iacs-runtime-*'))
record=json.loads((run/'result.json').read_text())
code='''import hashlib, importlib, json
from pathlib import Path
from app.api.v1 import integrations
from app.services import integration_settings, settings, settings_activation
from app.modules.notifications import apprise_urls
files=[Path(m.__file__) for m in [integrations,integration_settings,settings,settings_activation,apprise_urls]]
print(json.dumps({"imports":"passed","installed_sha256":{str(p.relative_to(Path('/app'))):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}))
'''
cmd=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,nodev,size=128m','--env','IACS_ENVIRONMENT=testing','--env','IACS_AUTO_CREATE_SCHEMA=false','--env','IACS_DATABASE_URL=postgresql+asyncpg://validation:synthetic-only@127.0.0.1:1/synthetic','--env','IACS_REDIS_URL=redis://127.0.0.1:1/0','--env','IACS_AUTH_SECRET_KEY=synthetic-import-check-never-production','--env','IACS_DATA_DIR=/tmp/data','--env','IACS_LOG_DIR=/tmp/logs','--entrypoint','python',record['image']['id'],'-c',code]
p=subprocess.run(cmd,capture_output=True,text=True)
(base/'runtime-imports.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
result=json.loads(p.stdout.strip().splitlines()[-1]); expected=record['source_sha256']
for name,value in result['installed_sha256'].items():assert expected['backend/'+name]==value,name
result.update(exit_code=p.returncode,image=record['image'],source_fingerprint=record['source_fingerprint'],network='none',source_or_dependency_overlays=False,lifespan_started=False,command=cmd)
(base/'runtime-imports.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['command','installed_sha256']}))
