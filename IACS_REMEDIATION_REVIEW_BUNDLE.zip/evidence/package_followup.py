"""Package the focused follow-up against its captured dirty starting tree."""
from __future__ import annotations
import ast
import difflib
import hashlib
import json
import re
import shutil
import sys
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=Path('/Users/jas/Documents/Intelligent Access System')
INITIAL=BASE/'iacs-validation-ieb32j6y'
RUN=BASE/'iacs-validation-c1ylh8yt'
BEFORE=BASE/'iacs-validation-focus-_16peat7'
FOCUS=BASE/'iacs-validation-focus-igwiz0e1'
RUNTIME=BASE/'runtime-accepted/iacs-runtime-pdf-1r5mfym4'
DELIVERY=['IACS_REMEDIATION_HANDOVER.md','IACS_REMEDIATION_EVIDENCE.json']
BUNDLE=ROOT/'IACS_REMEDIATION_REVIEW_BUNDLE.zip'

def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def mode(p):return '100755' if p.stat().st_mode & 0o111 else '100644'
def blob(p):
 b=p.read_bytes();return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def patch(path,before,after):
 a=before.read_text().splitlines(keepends=True) if before else []
 b=after.read_text().splitlines(keepends=True) if after else []
 out=['diff --git a/'+path+' b/'+path+'\n']
 if before is None:out+=['new file mode '+mode(after)+'\n']
 elif after is None:out+=['deleted file mode '+mode(before)+'\n']
 elif mode(before)!=mode(after):out+=['old mode '+mode(before)+'\n','new mode '+mode(after)+'\n']
 out+=['index '+(blob(before) if before else '0'*40)+'..'+(blob(after) if after else '0'*40)+'\n']
 for line in difflib.unified_diff(a,b,fromfile='a/'+path if before else '/dev/null',tofile='b/'+path if after else '/dev/null'):
  out.append(line if line.endswith('\n') else line+'\n\\ No newline at end of file\n')
 return out

def category(p):
 if p in DELIVERY or p.startswith('docs/'):return 'documentation'
 if '/generated/' in p:return 'generated_contracts'
 if '/alembic/' in p:return 'migrations'
 if '/tests/' in p or '/test_' in p or '.test.' in p or '/e2e/' in p:return 'tests'
 if p.startswith('scripts/validation/'):return 'validation_configuration'
 return 'production_code'

def cases(p):
 return ET.parse(p).getroot().findall('.//testcase')
def counts(p):
 c=cases(p);failed=sum(x.find('failure') is not None for x in c);errors=sum(x.find('error') is not None for x in c);skipped=sum(x.find('skipped') is not None for x in c)
 return dict(total=len(c),passed=len(c)-failed-errors-skipped,failed=failed,errors=errors,skipped=skipped)
def result(p):
 r=read(p/'results.json');return dict(exit_code=0 if not any(type(v)is int and v!=0 for v in r.values()) and not any(k.endswith('error') for k in r) else 1,codes=r)
def owner(path,symbol):
 line=next(i for i,l in enumerate((ROOT/path).read_text().splitlines(),1) if re.search(r'\b'+re.escape(symbol)+r'\b',l) and (l.lstrip().startswith(('def ','async def ','class ','export ')) or symbol=='removeAppriseUrl'))
 return dict(path=path,symbol=symbol,line=line)
def link(o):return f"[{o['path']}:{o['line']}](<{ROOT/o['path']}:{o['line']}>) (`{o['symbol']}`)"

start,final=read(INITIAL/'manifest.json'),read(RUN/'manifest.json')
old,new=start['sha256'],final['sha256']
assert start['source_fingerprint']=='a773364a0933db096464143bb8941f87e3dc5a3874f73e03ea68a18b47ed3d1f'
assert final['source_fingerprint']=='1bc3838659160f422bad2e5800473da993188f4746f0c1e338c11beaa396a557'
assert git('rev-parse','HEAD')==start['commit'] and git('branch','--show-current')==start['branch']
if '--allow-staged' not in sys.argv:
 assert git('diff','--cached','--name-only')==''
import sys
sys.path.insert(0,str(ROOT/'scripts/validation'))
from source_snapshot import discover_sources,excluded_path,source_fingerprint
selected,selection=discover_sources(ROOT,final['inventory']['explicit_includes'])
actual={p:sha(ROOT/p) for p in selected if p not in DELIVERY+[BUNDLE.name] and not excluded_path(p) and (ROOT/p).is_file()}
assert actual==new
assert source_fingerprint(actual)==final['source_fingerprint']
changes=sorted(p for p in old.keys()|new.keys() if old.get(p)!=new.get(p))
assert len(changes)==20
full=result(RUN); assert full['exit_code']==0,full
assert all(full['codes'].get(f'suite-{i:03d}')==0 for i in range(1,61)),list(full['codes'])[-8:]
assert full['codes']['cleanup']==0 and full['codes']['source_integrity']==0 and full['codes']['production_unchanged'] is True
assert read(RUNTIME/'result.json')['status']=='passed'
assert read(RUNTIME/'result.json')['source_fingerprint']==final['source_fingerprint']
assert read(BASE/'runtime-imports.json')['source_fingerprint']==final['source_fingerprint']
assert '58 passed' in (BASE/'browser/console.log').read_text()
assert read(BASE/'browser/source-manifest.json')['sha256']=={p:h for p,h in new.items() if p.startswith('frontend/')}
assert result(FOCUS)['exit_code']==0
beforecases=cases(BEFORE/'artifacts/suite-001/junit.xml')
aftercases=cases(RUN/'artifacts/suite-004/junit.xml')
assert counts(BEFORE/'artifacts/suite-001/junit.xml')==dict(total=23,passed=7,failed=16,errors=0,skipped=0)
assert counts(RUN/'artifacts/suite-004/junit.xml')==dict(total=23,passed=23,failed=0,errors=0,skipped=0)
after_by_name={c.attrib['name']:c for c in aftercases}
paired=[]
for c in beforecases:
 n=c.attrib['name'];assert n in after_by_name
 fail=c.find('failure');paired.append(dict(name=n,before='failed' if fail is not None else 'passed',after='passed',before_detail=(fail.attrib.get('message','') if fail is not None else '')[:600]))
write(BASE/'paired-regression-results.json',paired)
suites=read(RUN/'persistence-suites.json');assert len(suites)==60
suitecounts={row['check']:counts(RUN/row['evidence']/'junit.xml') for row in suites}
backendcounts=counts(RUN/'artifacts/backend-tests/junit.xml')
assert backendcounts['passed']==1565 and backendcounts['skipped']==35
skips=[c.attrib['name'] for c in cases(RUN/'artifacts/backend-tests/junit.xml') if c.find('skipped') is not None]
counterparts=[]
for n in skips:
 hits=[row['check'] for row in suites if any(c.attrib['name']==n and c.find('skipped') is None and c.find('failure') is None for c in cases(RUN/row['evidence']/'junit.xml'))]
 assert hits,n
 counterparts.append(dict(test=n,passing_suites=hits))
write(BASE/'skip-counterparts.json',counterparts)
persistence_total=sum(c['passed'] for c in suitecounts.values())
write(BASE/'final-test-summary.json',dict(backend=backendcounts,persistence_suites=len(suites),persistence_cases=persistence_total,suites=suitecounts,skip_counterparts='skip-counterparts.json'))
# Prove no previous test function was removed in the follow-up source selection.
removed=[];added=[]
for p in changes:
 if p.endswith('.py') and ('/tests/' in p or '/test_' in p):
  def names(path):
   return {n.name for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')} if path else set()
  a=names(INITIAL/'source'/p if p in old else None);b=names(RUN/'source'/p if p in new else None)
  removed.extend(p+'::'+n for n in a-b);added.extend(p+'::'+n for n in b-a)
assert not removed
write(BASE/'test-inventory-delta.json',dict(removed_python_tests=removed,added_python_test_functions=sorted(added),new_parameterized_api_cases=23,prior_test_suites_preserved=True,frontend_change='One stale Apprise browser scenario added; existing fixture and client-contract assertions migrated; no test files removed.'))

source_manifest=[];stats={};sourcepatch=[]
for p in changes:
 a=INITIAL/'source'/p if p in old else None;b=RUN/'source'/p if p in new else None
 diff=patch(p,a,b);sourcepatch+=diff
 plus=sum(l.startswith('+') and not l.startswith('+++') for l in diff);minus=sum(l.startswith('-') and not l.startswith('---') for l in diff)
 cat=category(p);d=stats.setdefault(cat,dict(files=0,added_lines=0,deleted_lines=0,new_files=0,deleted_files=0))
 d['files']+=1;d['added_lines']+=plus;d['deleted_lines']+=minus;d['new_files']+=p not in old;d['deleted_files']+=p not in new
 source_manifest.append(dict(path=p,status='new' if p not in old else 'deleted' if p not in new else 'modified',category=cat,starting_sha256=old.get(p),final_sha256=new.get(p),added_lines=plus,deleted_lines=minus))
write(BASE/'followup-source-changes.json',source_manifest)
(BASE/'followup-source-only.patch').write_text(''.join(sourcepatch))
write(BASE/'preexisting-context.json',dict(branch=start['branch'],head=start['commit'],source_fingerprint=start['source_fingerprint'],working_tree_status=start['status'],delivery_documents={p:sha(BASE/'prior-context'/p) for p in DELIVERY},previous_bundle_sha256=sha(BASE/'prior-context/IACS_REMEDIATION_REVIEW_BUNDLE.zip'),note='All prior dirty work is the follow-up baseline. No Git HEAD-only diff is used.'))

owners1=[owner('backend/app/services/settings.py','update_settings'),owner('backend/app/services/settings_activation.py','SettingsActivationCoordinator'),owner('backend/app/services/integration_settings.py','apply_integration_edit'),owner('backend/app/api/v1/integrations.py','update_integration_settings')]
owners2=[owner('backend/app/services/integration_settings.py','apprise_destinations'),owner('backend/app/api/v1/integrations.py','remove_apprise_url'),owner('frontend/src/api/integrations.ts','removeAppriseUrl')]
review=dict(requested_model='gpt-6-astra',requested_effort='medium',delegation='Existing /root/astra_review reused with explicit original model/effort request; no new reviewer or CLI/cloud session.',effective_model_and_effort='unverified; tool session does not expose effective model/effort or custom overrides',status='Scoped independent review completed; no material finding; effective model identity unverified',initial_target=dict(fingerprint='8ab88de886ba15d56de4cb44b17862f774c703b19e1a701637fc4a90e225f7db',diff='review.patch',manifest='review-manifest.json',report='review-checkpoints.json'),final_delta=dict(fingerprint=final['source_fingerprint'],scope='Two null name/host normalization lines, compatibility API test, AST-identical EOF cleanup',finding='No material finding; null host rejects, omitted encryption key is preserved, explicit empty key clears.'),limitations=['Not a repository-wide certification','Initial review preceded final full harness completion; final validation evidence sent separately','Effective reviewer model identity not independently exposed'])
write(BASE/'review-checkpoints.json',review)
prior=read(BASE/'prior-context/IACS_REMEDIATION_EVIDENCE.json')
full_command='IACS_VALIDATION_BACKEND_IMAGE=iacs-backend:uiprotect-23-backfill-verified-20261013 PYTHONDONTWRITEBYTECODE=1 <bundled-python3.12> scripts/validation/validate.py --allow-downloads --reuse-dependencies '+str(BASE/'iacs-validation-focus-rstp6hsg')+' --evidence-root '+str(BASE)
tests=[dict(name='Paired starting-code API/PostgreSQL regression',command='focused.py --source '+str(INITIAL/'source')+' --test-overlay scripts/validation/test_integration_mutations.py --suite scripts/validation/test_integration_mutations.py',exit_code=1,result='16 failed / 7 passed; expected behavioral baseline, zero setup errors',run=BEFORE.name,artifact='evidence/'+BEFORE.name+'/suite-001.log'),dict(name='Focused after-fix real API/storage and activation',command='focused.py --suite scripts/validation/test_integration_mutations.py --suite scripts/validation/test_settings_configuration.py --unit tests/test_settings_activation.py',exit_code=0,result='23 API/PostgreSQL + 20 settings PostgreSQL + 14 activation tests passed',run=FOCUS.name,artifact='evidence/focused-compatibility-console.log'),dict(name='Full final isolated harness',command=full_command,exit_code=0,result=f'1565 backend passed / 35 persistence-only skips; frontend 61 files / 367 tests; 60 suites / {persistence_total} cases; all checks passed',run=RUN.name,artifact='evidence/'+RUN.name+'/results.json'),dict(name='Affected Chromium and WebKit browser checks',command='node /opt/node_modules/playwright/cli.js test e2e/provider-editors.spec.ts e2e/integration-receipts.spec.ts --workers=1',command_recording='Test entrypoint and options known; original Docker wrapper argv was not saved. Image, frontend hashes, one worker, network-none isolation and strict inert fixtures are recorded; wrapper flags are not invented.',exit_code=0,result='58 passed; no backend proxy, strict inert API mocks, unchanged 30-second test timeout',artifact='evidence/browser/console.log',source_parity='Every frontend input hash equals final harness manifest',image={'reference':'iacs-followup-browser:20261014','id':'sha256:869763af86eddab1993de1041448eccb1821e5ffa9328d54202aedc607394a87'},isolation={'network':'none','workers':1,'test_timeout_seconds':30,'CI':'1','port':5174,'backend_proxy':False},tooling='evidence/browser-tooling/Dockerfile'),dict(name='Final runtime build and PDF',command='scripts/validation/runtime_pdf_smoke.py --build --image iacs-backend:integration-mutations-accepted-runtime-20261014 --evidence-root '+str(BASE/'runtime-accepted'),exit_code=0,result='Passed; non-root, network none, no installed-source or dependency overlays',artifact='evidence/runtime-accepted/iacs-runtime-pdf-1r5mfym4/result.json'),dict(name='Final installed runtime imports/hash parity',command='python3 '+str(BASE/'check_runtime.py'),exit_code=0,result='Changed owners import; installed hashes match final source; no lifespan/provider startup',artifact='evidence/runtime-imports.json'),dict(name='Host snapshot tests',command='python3 scripts/validation/test_source_snapshot.py',exit_code=0,result='22 passed',artifact='evidence/host-source-snapshot.log'),dict(name='Host harness configuration tests',command='python3 scripts/validation/test_harness_configuration.py',exit_code=0,result='30 passed',artifact='evidence/host-harness-configuration.log')]
requirements={k:dict(status=v['status'],verification_scope='Earlier remediation; carried forward, broad prior delta not part of follow-up patch',prior_evidence='prior-remediation/IACS_REMEDIATION_EVIDENCE.json') for k,v in prior['requirements'].items()}
requirements['V01']=dict(status='fixed',verified=True,root_cause='Routes built replacement lists before coordinator admission; successful compound edits could overwrite accepted concurrent changes.',correction='Explicit ESPHome, Apprise and HA discovery operations apply to freshly locked authoritative values in settings persistence, then canonical validation/audit/commit and existing owned activation; safe accepted representations prepared before commit.',owners=owners1,regression_tests=[p['name'] for p in paired if any(s in p['name'] for s in ['add','patch','discovery','cancellation','audit','current_actor','null_host'])],before='Lost updates reproduced with real concurrent route entry, including separate coordinators; 16/23 baseline failures include V02 and guarded status/privacy contracts.',after='All 23 API/PostgreSQL cases pass; full harness repeats suite-004.',evidence=['evidence/paired-regression-results.json','evidence/'+RUN.name+'/suite-004.log'])
requirements['V02']=dict(status='fixed',verified=True,root_cause='Index-only deletion confirmation could substitute the next destination after list shifts.',correction='Required opaque HMAC destination identity plus ordered-list revision bind confirmation and mutation under the same settings locks; stale binding returns 409, index-only clients 422; fresh duplicate selection removes exactly one occurrence; UI uses accepted authoritative URLs.',owners=owners2,regression_tests=[p['name'] for p in paired if any(s in p['name'] for s in ['deletion','reordering','duplicate','index_only','confirmation','credentials','approved_delete'])],before='Preceding deletion, reorder/duplicate and concurrency regressions fail on captured starting application.',after='All 23 API/PostgreSQL and affected58 browser checks pass.',evidence=['evidence/paired-regression-results.json','evidence/browser/console.log'])
evidence=dict(schema_version=2,scope='V01/V02 focused local follow-up; previous remediation retained as explicitly historical context',root=str(ROOT),git=dict(starting_head=start['commit'],final_head=git('rev-parse','HEAD'),starting_branch=start['branch'],final_branch=git('branch','--show-current'),original_review_sha=prior['git']['original_review_sha'],preexisting_edits='evidence/preexisting-context.json',staged_changes=False,task_committed=False),fingerprints=dict(starting=start['source_fingerprint'],final_tested=final['source_fingerprint'],algorithm='sha256(sorted(relative_path + NUL + file_sha256 + newline))',starting_manifest='evidence/'+INITIAL.name+'/manifest.json',final_manifest='evidence/'+RUN.name+'/manifest.json',delivery_documents='Written after final code validation; excluded from code fingerprint; included in task-only patch and bundle manifest hashes'),artifact_base=str(BASE),portable_artifact_base='.',task_change_manifest='followup-change-manifest.json',task_only_patch='task-only.patch',statistics=dict(source=stats,delivery_documents=dict(modified=2,generated_archive=1)),requirements=requirements,tests=tests,paired_results='evidence/paired-regression-results.json',skip_accounting='evidence/skip-counterparts.json',test_inventory='evidence/test-inventory-delta.json',model=dict(primary_requested='gpt-6.1-sol/xhigh',primary_effective='unverified; not exposed',review=review,token_usage='unavailable',last_account_window_remaining_percent=86,pause_threshold_remaining_percent=20),ownership=dict(before='Routes read cached config, build replacement lists and return caller-built arrays; coordinator serialized only later persistence/activation.',after='Routes collect intent/discovery facts; explicit integration edit owner applies operations under settings transaction locks; settings owns validation/current actor/audit/commit and accepted representation; coordinator retains cancellation-aware serialized activation; clients display accepted representations.'),retained_failures=dict(summary='evidence/retained-runs.json',baseline='Expected failures distinguish actual lost-work/mis-target behavior from missing new public binding fields and actor error-code normalization. Revoked actor was already denied400; final403 makes denial precise, not a claim that old code authorized it.',interrupted_full_runs=['iacs-validation-m0oijkr4','iacs-validation-y51k98t2','iacs-validation-ukmq3qtr']),contracts=dict(apprise_delete='index path plus required destination_id and revision in confirmation payload and DELETE body; obsolete index-only422; stale list409; refresh and deliberate new approval; no automatic resend',duplicates='One approved occurrence removed only when ordered list/multiplicity matches; add remains deduplicated no-op',auth_root_rotation='Changes invalidate opaque bindings safely; refresh destinations and confirm again',privacy='Opaque keyed fingerprints and service/ordinal previews; no credential prefix in public metadata',schema='No follow-up migration/dependency change',calendar='Earlier retirement preserved, not reopened'),blockers=[],remaining_limits=['Effective primary/reviewer model metadata unavailable','Real provider/hardware/browser-to-live-backend tests intentionally not executed','Historical C01 snapshot attachment product choice remains deferred as previously documented','Synthetic tests do not establish production latency or exactly-once network delivery'],prior_context=dict(evidence='prior-remediation/IACS_REMEDIATION_EVIDENCE.json',handover='prior-remediation/IACS_REMEDIATION_HANDOVER.md',patch='prior-remediation/task-only.patch',historical_log_link_repaired='prior-remediation/evidence/full-final-8-console.log',original_prior_delivery='evidence/prior-context/'),production=dict(migrated=False,deployed=False,live_provider_calls=False,live_container_restarts=False),bundle_validation=dict(report='evidence/bundle-content-verification.json',local_archive_inventory_report=str(BASE/'bundle-inspection.json'),checks=['relative safe paths','CRC and every member hash','secret-marker scan','apply follow-up-only patch to included starting bytes and compare all final bytes','prior context separated']))
write(ROOT/DELIVERY[1],evidence)
ownerlinks='\n'.join('- '+link(o) for o in owners1+owners2)
testrows='\n'.join(f"| {t['name']} | {t['exit_code']} | {t['result']} | `{t['artifact']}` |" for t in tests)
statrows='\n'.join(f"| {k} | {v['files']} | +{v['added_lines']} / −{v['deleted_lines']} | {v['new_files']} / {v['deleted_files']} |" for k,v in stats.items())
pairedrows='\n'.join(f"| `{p['name']}` | {p['before']} | {p['after']} |" for p in paired)
oldtext=(BASE/'prior-context'/DELIVERY[0]).read_text().replace('full-final-6-console.log','full-final-8-console.log')
text=f'''Two remaining integration-edit defects are fixed in the local IACS files. Concurrent ESPHome, Apprise and Home Assistant discovery edits now apply to fresh configuration inside the existing settings transaction, so two successful additions preserve both. Apprise deletion also binds approval to the exact destination and list revision: if another screen removes an earlier entry, the stale request reports a conflict instead of removing the wrong destination.

All earlier uncommitted remediation is preserved. The real API/PostgreSQL regression inventory went from **16 failed / 7 passed** on the captured starting application to **23 passed**. The final isolated harness, affected browser checks and runtime checks pass. Changes remain local and uncommitted; production was not migrated or deployed, live containers were not restarted, and no real providers or hardware were contacted. Deploy the matching backend/frontend together later under separate authorization; refresh old Apprise editors and confirm stale deletions again.

## Focused follow-up technical appendix (V01/V02)

### Identity, scope and inspectable artifacts

- Workspace: `{ROOT}`. Starting and final branch `main`, HEAD `{start['commit']}`. No branch/worktree switch, staging, commit or remote operation.
- Follow-up starting **actual dirty tree**: `{start['source_fingerprint']}` ({len(old)} safe source files). Final tested source: **`{final['source_fingerprint']}`** ({len(new)} files). HEAD alone does not identify either tree.
- Fingerprint algorithm: SHA-256 of sorted relative path, NUL, per-file SHA-256, newline. Safe manifests exclude secrets, production state, dependencies and caches. The root delivery documents were written after code validation and have separate bundle hashes.
- Local evidence folder: `{BASE}`. Portable paths in this document refer to members inside [the review bundle](<{BUNDLE}>). The earlier bundle's contents are under `prior-remediation/`; its source patch is historical. The top `task-only.patch` contains **only this follow-up**, compared with captured starting bytes, including the two root delivery documents. The earlier Git-dirty work is not attributed to this delta.
- [Machine-readable evidence](<{ROOT/DELIVERY[1]}>); `followup-change-manifest.json` lists every task modification/new file; `evidence/preexisting-context.json` records the pre-existing dirty status and prior artifact hashes. No follow-up source was deleted. Three selected source/test files are new; the remaining 17 are modifications. Generated workflow contracts, migrations and dependency manifests have no follow-up delta.

| Category | Files | Added / deleted lines | New / deleted files |
| --- | --- | --- | --- |
{statrows}

These statistics cover selected source/docs/test/harness files only. The two modified delivery documents and regenerated archive are counted separately in JSON; old remediation line totals below are historical.

### Findings and corrections

| ID | Status | Root cause and correction | Before / after |
| --- | --- | --- | --- |
| V01 | Fixed, tested, scoped independent review completed | Cached read→replacement-list assembly occurred before save admission. Explicit typed ESPHome/Apprise/cover-discovery operations now run after the existing current-actor, target/configuration and settings locks, against fresh decrypted values. Canonical validation, required atomic audit, encryption and commit remain owned by settings. The coordinator owns the admitted persistence→activation lifetime. Accepted sanitized representations are constructed before commit and returned in the saved receipt. | Concurrent add/add (including two coordinators), add/remove, independent field edits, Apprise edits and post-discovery merge failures reproduced on starting code; final API/PostgreSQL suite 23 passes. |
| V02 | Fixed, tested, scoped independent review completed | An index-only approval could remove a different entry after a shift. Required keyed opaque destination and ordered-list revision fingerprints now bind approval payload and DELETE body. The same locked operation validates both, then removes exactly one occurrence. Any change to order/multiplicity makes old approval conflict 409; obsolete index-only request 422. Public previews use service/ordinal, without credential prefixes. Frontend confirmation, typed API, panel and fixtures migrated together; UI consumes accepted URLs. | Real preceding deletion/reorder/duplicate/stale/concurrent tests reproduce the old defect or absent new binding; all 23 API/storage cases and 58 affected browser cases pass. |

Current owners and exact symbols:

{ownerlinks}

`backend/app/modules/notifications/apprise_urls.py` owns pure URL normalization/safe summaries; vendor parsing/sending remains in `apprise_client.py`. Moving these helpers prevents a settings/vendor dependency cycle and preserves notification recipient ID vocabulary. No compatibility alias, index-only bypass, versioning platform or generic mutation framework was introduced. `update_integration_settings` no longer accepts unused before/after arguments; callers no longer construct discarded summaries.

HA discovery performs provider I/O before settings locks; only collected entity facts enter the locked merge. Existing manual entity fields and the current default open service are preserved. No allow decision or provider observation is cached as authority. Existing settings activation/no-op/partial failure/cancellation/queued cancellation/shutdown tests remain intact. Explicit null device host still rejects 400; omitted encryption key is preserved and an explicit empty key clears, matching the starting route behavior.

Ownership before: route cached read + whole list + unused summaries → coordinator serializes save/activation. Ownership after: route intent/discovery facts → explicit integration operation applied under fresh settings transaction → validation/audit/commit/accepted representation → existing cancellation-aware activation → UI accepted receipt. To extend an existing compound integration edit, add a concrete typed operation to this owner, apply it against locked current values, return its safe accepted representation and add route/storage concurrency tests. A provider remains responsible only for discovery/I/O.

### Exact regression inventory and retained failures

The same final 23-case API test file was overlaid on the immutable starting source for the paired baseline. Application code remained byte-identical to the starting snapshot. Tests use real FastAPI routes, bearer authentication, confirmation API, PostgreSQL, audit and persistence owners; provider discovery/restarts alone are inert. The isolation guard rejects other sockets/HTTP, application workers/lifespan are not started. Route-entry barriers expose the earlier read-before-save race, rather than merely enqueueing prebuilt coordinator payloads.

| Test (parameter cases are separate) | Starting application | Final application |
| --- | --- | --- |
{pairedrows}

`evidence/paired-regression-results.json` includes the exact baseline assertion messages. The actor-revalidation case was denied by the old service with 400 and now returns 403; it was not an authorization bypass. Some V02 cases fail on the baseline because opaque binding fields did not exist; the preceding-deletion and concurrent mutation cases demonstrate the underlying behavior. Setup failures were not counted as these sixteen behavioral/contract failures.

Earlier attempts are retained in `evidence/retained-runs.json` with command/result/log evidence: an unavailable old image, correctly rejected mismatched dependency cache, initial fixture teardown guard failures, and a test expecting 403 for an already-consumed confirmation instead of the existing 409. The assertion was corrected; confirmation/audit guards were preserved. Three earlier full attempts were interrupted for relevant source/test corrections or whitespace cleanup; none is claimed as a complete pass. The final run below is the completion evidence. No previous Python test functions or test files were removed; the new suite adds 23 cases, one stale-delete browser scenario was added, and existing response fixtures were migrated.

### Final validation

| Check | Exit | Actual result | Portable evidence |
| --- | --- | --- | --- |
{testrows}

The final full run is `{RUN.name}`. Its `checks.json` holds exact commands, synthetic environment and isolation mounts; `results.json` records every exit code. All 60 persistence/diagnostic suites, migration upgrades/checks, schema drift, database restore rehearsal, architecture boundaries, strict types (132 source files), lint, compile, generated contracts, lock/tree checks and frontend build pass. Cleanup/source integrity exit0 and production-unchanged=true. The 35 backend unit skips are journal tests deliberately executed against PostgreSQL in the full persistence inventory; all have passing exact-name counterparts in `evidence/skip-counterparts.json`. No additional exclusions were added.

The browser test entrypoint/options are recorded; its original Docker wrapper argv was not saved, so the evidence does not invent wrapper flags. Image identity, isolation configuration, frontend hashes and the actual console result are retained. 58 browser tests passed on Chromium/WebKit with one worker, unchanged 30-second test limits, CI=1, owned port5174, strict inert API fixtures, no backend proxy and network disabled. Every frontend input hash equals the final harness source; later changes were backend-only compatibility normalization/test and AST-identical EOF cleanup. Broader unrelated layout/browser suites were not rerun in this follow-up; the historical 106-case run remains historical evidence below.

Final runtime image `{read(RUNTIME/'result.json')['image']['id']}` is non-root. The build used final local source, and PDF/import smoke checks had network disabled and no source/dependency overlays; installed changed-owner hashes equal the final manifest. Dependency audit reports from the previous unchanged locks remain historical; final harness rechecked exact locks/dependency identity, with no follow-up dependency changes. No performance claim or new benchmark is made for this mutation correctness fix; earlier R06 measurements below remain historical.

### Independent review and limits

One existing reviewer was reused for the actual immutable follow-up delta, originally requested explicitly as **gpt-6-astra / medium**. Review target `{review['initial_target']['fingerprint']}` covered actual new/uncommitted source, callers, storage tests and strict targets, via `review.patch` and `review-manifest.json`. It found no material issue with locked edits, actor/audit ownership, authoritative receipts, approval binding, duplicates or client migration. A targeted follow-up reviewed only the two explicit null normalization lines/new compatibility test and EOF cleanup at final fingerprint `{final['source_fingerprint']}` and found no material issue. Reviewed files were stable snapshots; no reviewer edited application files or operated integrations. Final check results were provided separately after completion.

Effective primary model/effort and reviewer model/effort are **unverified because session metadata is not exposed**, including custom overrides. A role name is not model proof; no simulated Astra approval is claimed. Requested primary remains Sol Extra High. Token counts are unavailable. The last observed usage window had86% remaining, above the user's pause threshold of20% remaining. This was a scoped independent delta review, not whole-repository certification; previously underexamined unrelated files were not reopened.

### Verification and owner actions

1. Extract the bundle; inspect top `followup-change-manifest.json`, `task-only.patch`, `starting/` and `final/`. Check its hashes/CRC and the final source fingerprint. `prior-remediation/` preserves earlier remediation context separately; exact original delivery documents are under `evidence/prior-context/`.
2. Read settings locks/commit and coordinator admission, then `integration_settings.py`, routes and frontend deletion caller/panel. Inspect 23 real API cases and `suite-004` logs before relying on source-extracted reproductions. Read exact baseline failures and final JUnit counterparts.
3. Verify no index-only caller/confirmation bypass exists; inspect opaque IDs/privacy, stale409, duplicateone-occurrence semantics, authoritative saved responses and all 14 activation +20 settings real-storage regressions. Inspect browser stale-delete assertions and final runtime installed hashes.
4. Later deploy backend/frontend together under separate authorization; stale screens/approvals must refresh and get a new confirmation. This follow-up has no schema migration. Earlier calendar retirement upgrade/rollback instructions below still apply to the undelivered combined local remediation; production was not migrated or deployed. No rollback restores deleted credentials automatically.

The previous handover's stale `full-final-6-console.log` reference is repaired to the actual historical `prior-remediation/evidence/full-final-8-console.log`. The prior archive's original bytes/hashes and exact delivery documents are preserved as provenance; its extracted readable handover has that one link correction. Bundle inventory excludes secrets, .env credentials, .git, production data, dependencies and caches; the follow-up patch is checked/applied only to an inert copy of included starting files and all final bytes compared. External inspection result: `{BASE/'bundle-inspection.json'}`.

Historical C01 attachment optionality remains the existing deferred product choice; this follow-up does not change it. Real providers/hardware, live application lifespans, production migrations and deployment were intentionally not executed. Synthetic validation does not prove audible playback, exactly-once delivery or production speedups. No unresolved V01/V02 material finding remains.

## Earlier remediation context — historical, completed before this follow-up

The following preserved narrative describes the previous R01–R09/R10/R11/C01 work and its earlier fingerprint, test runs and review checkpoints. Those changes were already present at the follow-up start; they are **not** this follow-up's implementation or current final fingerprint. Its artifact paths live under `prior-remediation/evidence/` inside the portable bundle, or the original local evidence folder identified below. The original source/diffs/manifests are retained there. The full-final8 log typo is corrected in this readable copy.

{oldtext}
'''
(ROOT/DELIVERY[0]).write_text(text.rstrip()+'\n')
# Prepare the exact task patch including modified root delivery docs.
delivery=[];allpatch=list(sourcepatch)
for p in DELIVERY:
 a=BASE/'prior-context'/p;b=ROOT/p;diff=patch(p,a,b);allpatch+=diff
 delivery.append(dict(path=p,status='modified',category='documentation',starting_sha256=sha(a),final_sha256=sha(b),added_lines=sum(l.startswith('+') and not l.startswith('+++') for l in diff),deleted_lines=sum(l.startswith('-') and not l.startswith('---') for l in diff)))
change_manifest=dict(source_changes=source_manifest,delivery_documents=delivery,new_files=[r['path'] for r in source_manifest if r['status']=='new'],deleted_files=[r['path'] for r in source_manifest if r['status']=='deleted'],generated_archive=BUNDLE.name,starting_fingerprint=start['source_fingerprint'],final_tested_fingerprint=final['source_fingerprint'],preexisting_context='evidence/preexisting-context.json')
write(BASE/'followup-change-manifest.json',change_manifest)
(BASE/'task-only.patch').write_text(''.join(allpatch))
# Carry failures and interrupted work forward without calling them final passes.
retained=[]
for p in sorted(BASE.glob('iacs-validation-*')):
 if p in [INITIAL,RUN]:continue
 r=read(p/'results.json') if (p/'results.json').exists() else {'status':'no completed results'}
 logs={x.name:x.stat().st_size for x in p.glob('*.log')}
 retained.append(dict(run=p.name,results=r,logs=logs,final_completion_evidence=p==FOCUS,baseline_pair=p==BEFORE))
write(BASE/'retained-runs.json',retained)
# Static/doc checks after delivery text was written.
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True,stdout=(BASE/'diff-check-final.log').open('w'),stderr=subprocess.STDOUT)
for p in changes:
 b=(ROOT/p).read_bytes()
 assert b.endswith(b'\n') and not b.endswith(b'\n\n'),p
links=[]
for p in [ROOT/DELIVERY[0],ROOT/'docs/architecture.md',ROOT/'docs/integrations.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  path=target.strip('<>').split('#')[0];path=re.sub(r':\d+$','',path)
  resolved=Path(path) if path.startswith('/') else p.parent/path
  assert resolved.exists(),(p,target)
  links.append(dict(document=str(p.relative_to(ROOT)),target=target))
write(BASE/'docs-links-check.json',dict(status='passed',links_checked=len(links),delivery_written_after_code_validation=True,stale_historical_log='full-final-8-console.log'))
# Bundle payload: selected local source + compact reproducible evidence, not deps or state.
payload={}
def add(name,p):payload[name]=p.read_bytes()
for p in DELIVERY:add(p,ROOT/p);add('starting/'+p,BASE/'prior-context'/p);add('evidence/prior-context/'+p,BASE/'prior-context'/p)
for record in source_manifest:
 p=record['path']
 if p in old:add('starting/'+p,INITIAL/'source'/p)
 if p in new:add('final/'+p,RUN/'source'/p)
for p in DELIVERY:add('final/'+p,ROOT/p)
for n in ['task-only.patch','followup-change-manifest.json']:add(n,BASE/n)
for n in ['paired-regression-results.json','skip-counterparts.json','final-test-summary.json','test-inventory-delta.json','preexisting-context.json','review-checkpoints.json','bundle-content-verification.json','review-final-compatibility.txt','review.patch','review-manifest.json','review-final-parity.json','retained-runs.json','docs-links-check.json','diff-check-final.log','host-source-snapshot.log','host-harness-configuration.log','paired-baseline-console.log','focused-compatibility-console.log','final-harness-console.log','runtime-accepted-console.log','runtime-imports.log','runtime-imports.json','check_runtime.py','focused.py','package_followup.py','browser-image-build.log']:
 add('evidence/'+n,BASE/n)
for n in ['console.log','source-manifest.json']:add('evidence/browser/'+n,BASE/'browser'/n)
add('evidence/browser-tooling/Dockerfile',BASE/'browser-tooling/Dockerfile')
for p in [INITIAL,BEFORE,FOCUS,RUN]:
 for n in ['manifest.json','checks.json','results.json','persistence-suites.json','dependencies.json','images.json','image-references.json','cleanup.json','database-restore.json']:
  if (p/n).exists():add('evidence/'+p.name+'/'+n,p/n)
 if p!=INITIAL:
  for x in p.glob('*.log'):add('evidence/'+p.name+'/'+x.name,x)
  for x in (p/'artifacts').rglob('junit.xml'):add('evidence/'+p.name+'/'+x.relative_to(p).as_posix(),x)
for n in ['result.json','build.log','smoke.log']:add('evidence/runtime-accepted/'+RUNTIME.name+'/'+n,RUNTIME/n)
# Baseline/intermediate error logs remain portable without production inspections.
for p in sorted(BASE.glob('iacs-validation-*')):
 if p in [INITIAL,BEFORE,FOCUS,RUN]:continue
 for n in ['results.json','manifest.json','suite-001.log','backend-tests.log','frontend-tests.log']:
  if (p/n).is_file():add('evidence/attempts/'+p.name+'/'+n,p/n)
with zipfile.ZipFile(BASE/'prior-context/IACS_REMEDIATION_REVIEW_BUNDLE.zip') as z:
 assert z.testzip() is None
 for n in z.namelist():
  data=z.read(n)
  if n=='IACS_REMEDIATION_HANDOVER.md':data=data.replace(b'full-final-6-console.log',b'full-final-8-console.log')
  payload['prior-remediation/'+n]=data
# Preserve original prior bundle identity (not recursively embed another archive).
payload['prior-remediation/PROVENANCE.txt']=('Extracted from prior delivered archive SHA256 '+sha(BASE/'prior-context/IACS_REMEDIATION_REVIEW_BUNDLE.zip')+'. Earlier handover has one log-name typo repaired; exact original root delivery documents are under evidence/prior-context/. Prior bundle-manifest hashes describe its original archive, not that repaired handover. The top bundle manifest hashes all delivered current members.\n').encode()
manifest=dict(schema_version=2,starting_fingerprint=start['source_fingerprint'],final_tested_fingerprint=final['source_fingerprint'],source_changes=source_manifest,delivery_documents=delivery,statistics=stats,prior_context='prior-remediation/',archive_members=[dict(path=n,bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in sorted(payload.items())])
payload['bundle-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(BUNDLE,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,d in sorted(payload.items()):z.writestr(n,d)
# Verify inventory, paths, content markers, exact hashes and task-only patch application.
forbidden=re.compile(r'(^|/)(?:\.git|node_modules|\.venv|python-deps|js-deps|__pycache__|\.env(?:\.[^/]*)?|data|postgres|redis|logs)(?:/|$)')
secret_patterns=[r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}',r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',r'\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}']
with zipfile.ZipFile(BUNDLE) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for n in z.namelist():
  assert not n.startswith('/') and '..' not in Path(n).parts and not forbidden.search(n),n
  data=z.read(n);text=data.decode('utf-8')
  for pattern in secret_patterns:assert not re.search(pattern,text),(n,pattern)
 for r in manifest['archive_members']:
  data=z.read(r['path']);assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
 fixture=Path(tempfile.mkdtemp(prefix='bundle-patch-verification-',dir=BASE))
 for n in z.namelist():
  if n.startswith('starting/'):
   target=fixture/n.removeprefix('starting/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n))
 for args in [['--check'],[]]:
  proc=subprocess.run(['git','apply',*args,str(BASE/'task-only.patch')],cwd=fixture,capture_output=True,text=True)
  assert proc.returncode==0,proc.stderr
 for record in source_manifest+delivery:
  p=record['path'];target=fixture/p
  if record['status']=='deleted':assert not target.exists()
  else:assert sha(target)==record['final_sha256'] and target.read_bytes()==z.read('final/'+p),p
 assert not (fixture/'.git').exists()
 assert actual=={p:sha(ROOT/p) for p in new}
 inspection=dict(bundle=BUNDLE.name,sha256=sha(BUNDLE),bytes=BUNDLE.stat().st_size,members=len(z.namelist()),zip_crc='passed',relative_paths_and_exclusions='passed',member_hashes='passed',credential_marker_scan='passed; heuristic scan has no matches; selected files exclude secret/state paths',patch_check='passed',patch_application='passed against included inert starting bytes, no Git init',final_changed_bytes='passed',prior_work_attribution='earlier delta is only under prior-remediation; top patch compared actual follow-up baseline',fixture=fixture.name,final_tested_fingerprint=final['source_fingerprint'],production_operations=False)
 write(BASE/'bundle-inspection.json',inspection)
 write(BASE/'bundle-inventory.json',[dict(path=n,bytes=len(z.read(n))) for n in z.namelist()])
write(BASE/'progress.json',dict(completion_percent=100,baseline=start['source_fingerprint'],final_tested=final['source_fingerprint'],full_run=RUN.name,bundle_sha256=sha(BUNDLE),remaining_work=[]))
print(json.dumps(dict(source_files=len(changes),statistics=stats,full_persistence_cases=persistence_total,bundle=inspection),indent=2))
