"""Focused checks using the repository's isolation/container owners; not a full run."""
import argparse, json, pathlib, shutil, sys, tempfile
root=pathlib.Path('/Users/jas/Documents/Intelligent Access System')
sys.path.insert(0,str(root/'scripts/validation'))
import validate
from source_snapshot import copy_sources, discover_sources, source_fingerprint, changed_snapshot_sources
p=argparse.ArgumentParser(); p.add_argument('--source',type=pathlib.Path); p.add_argument('--suite',action='append',default=[]); p.add_argument('--unit',action='append',default=[]); p.add_argument('--test-overlay',action='append',default=[]); a=p.parse_args()
base=pathlib.Path(__file__).parent
run=pathlib.Path(tempfile.mkdtemp(prefix='iacs-validation-focus-',dir=base))
source=run/'source'
if a.source:
 old=json.loads((a.source.parent/'manifest.json').read_text()); paths=old['hashes'] if 'hashes' in old else old['sha256']; hashes=copy_sources(a.source,source,paths)
else:
 paths, selection=discover_sources(root); hashes=copy_sources(root,source,paths)
for relative in a.test_overlay:
 if not relative.startswith(('backend/tests/', 'scripts/validation/test_')): raise ValueError('Only regression tests may overlay baseline')
 hashes.update(copy_sources(root,source,[relative]))
(run/'manifest.json').write_text(json.dumps({'source_fingerprint':source_fingerprint(hashes),'hashes':hashes,'source':str(a.source or root),'focused_only':True},indent=2))
reuse=__import__('os').environ.get('IACS_REMEDIATION_REUSE','/Users/jas/Documents/IACS Regression Baselines/remediation-20261014/iacs-validation-focus-c0hs4k_1')
args=validate.arguments(['--allow-downloads']+(['--reuse-dependencies',reuse] if reuse!='none' else []))
validate.persistence_checks=lambda _: [(s,'persistence') for s in a.suite]
validate.schema_checks=lambda _: []
validate.LINT_COMMANDS={}
class Focus(validate.Harness):
 def check(self,name,command,required=False,timeout=1200,classification='static'):
  if name=='backend-tests' and a.unit:
   command=self.container(name,self.images['backend'],['/deps/.venv/bin/python',*validate.pytest_arguments(name,a.unit)],mounts=self.mounts,env=self.env,work='/workspace/backend')
  elif name in {'snapshot-tests','harness-configuration-tests','backend-tests','architecture-boundaries','compile','workflow-contracts','frontend-tests','frontend-build','compose-config'}:
   self.skip(name,'Explicitly excluded from focused run; full harness remains required'); return 0
  return super().check(name,command,required,timeout,classification)
 def container(self,name,img,command,**kwargs):
  if name=='isolation-db-free': self.images=json.loads((self.run/'images.json').read_text()); self.mounts=kwargs['mounts']; self.env=kwargs['env']
  return super().container(name,img,command,**kwargs)
h=Focus(args,run,source); print('Retained results:',run,flush=True)
before=h.production_state(); h.write('production-before.json',before)
try: h.execute()
except BaseException as e: h.results['focused_error']=f'{type(e).__name__}: {e}'
finally:
 h.cleanup(); h.results['source_integrity']=int(bool(changed_snapshot_sources(source,hashes))); h.results['production_unchanged']=before==h.production_state(); h.write('results.json',h.results)
print(json.dumps(h.results,indent=2)); sys.exit(int(any(type(v) is int and v != 0 for v in h.results.values()) or any(k.endswith('error') for k in h.results)))
