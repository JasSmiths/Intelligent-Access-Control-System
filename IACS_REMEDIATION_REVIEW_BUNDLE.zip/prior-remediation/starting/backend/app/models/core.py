import uuid
from datetime import date, datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    or_,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.db.base import Base
from app.models.enums import (
    AccessDecision,
    AccessDirection,
    AnomalySeverity,
    AnomalyType,
    GateCommandState,
    GateMalfunctionStatus,
    GroupCategory,
    MovementSagaState,
    PresenceState,
    TimingClassification,
    UserRole,
    VisitorPassStatus,
    VisitorPassType,
)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


class Group(Base, TimestampMixin):
    __tablename__ = "groups"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    category: Mapped[GroupCategory] = mapped_column(Enum(GroupCategory), nullable=False)
    subtype: Mapped[str | None] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)

    people: Mapped[list["Person"]] = relationship(back_populates="group")


class Person(Base, TimestampMixin):
    __tablename__ = "people"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    first_name: Mapped[str] = mapped_column(String(80), default="", nullable=False)
    last_name: Mapped[str] = mapped_column(String(80), default="", nullable=False)
    display_name: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    pronouns: Mapped[str | None] = mapped_column(String(24))
    profile_photo_data_url: Mapped[str | None] = mapped_column(Text)
    group_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("groups.id", ondelete="SET NULL"), index=True
    )
    schedule_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("schedules.id", ondelete="SET NULL"), index=True
    )
    garage_door_entity_ids: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    home_assistant_mobile_app_notify_service: Mapped[str | None] = mapped_column(String(255))
    missed_exit_recovery_enabled: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )
    missed_exit_recovery_tracker_entity_id: Mapped[str | None] = mapped_column(String(255))
    home_assistant_presence_input_boolean_entity_ids: Mapped[list[str]] = mapped_column(
        JSONB, default=list, nullable=False
    )
    home_assistant_presence_input_boolean_entry_action: Mapped[str] = mapped_column(
        String(20), default="turn_off", nullable=False
    )
    home_assistant_presence_input_boolean_exit_action: Mapped[str] = mapped_column(
        String(20), default="turn_off", nullable=False
    )
    notes: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    group: Mapped[Group | None] = relationship(back_populates="people")
    schedule: Mapped["Schedule | None"] = relationship(back_populates="people")
    vehicles: Mapped[list["Vehicle"]] = relationship(back_populates="owner")
    vehicle_assignments: Mapped[list["VehiclePersonAssignment"]] = relationship(
        back_populates="person",
        cascade="all, delete-orphan",
    )
    presence: Mapped["Presence | None"] = relationship(back_populates="person")


Index(
    "uq_people_recovery_tracker",
    Person.missed_exit_recovery_tracker_entity_id,
    unique=True,
    postgresql_where=text("missed_exit_recovery_tracker_entity_id IS NOT NULL"),
)


class AccessDevice(Base, TimestampMixin):
    __tablename__ = "access_devices"
    __table_args__ = (UniqueConstraint("key", name="uq_access_devices_key"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    key: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    schedule_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("schedules.id", ondelete="SET NULL"),
        index=True,
    )
    open_for_access: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False, index=True)

    schedule: Mapped["Schedule | None"] = relationship()
    provider_bindings: Mapped[list["AccessDeviceProviderBinding"]] = relationship(
        back_populates="access_device",
        cascade="all, delete-orphan",
        order_by="AccessDeviceProviderBinding.provider",
    )


class AccessDeviceProviderBinding(Base, TimestampMixin):
    __tablename__ = "access_device_provider_bindings"
    __table_args__ = (
        UniqueConstraint("access_device_id", "provider", name="uq_access_device_provider"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    access_device_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("access_devices.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    provider: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    external_id: Mapped[str] = mapped_column(String(255), nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    config: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)

    access_device: Mapped[AccessDevice] = relationship(back_populates="provider_bindings")


class Vehicle(Base, TimestampMixin):
    __tablename__ = "vehicles"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    schedule_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("schedules.id", ondelete="SET NULL"), index=True
    )
    registration_number: Mapped[str] = mapped_column(
        String(32), unique=True, index=True, nullable=False
    )
    vehicle_photo_data_url: Mapped[str | None] = mapped_column(Text)
    make: Mapped[str | None] = mapped_column(String(80))
    model: Mapped[str | None] = mapped_column(String(120))
    color: Mapped[str | None] = mapped_column(String(80))
    fuel_type: Mapped[str | None] = mapped_column(String(80))
    mot_status: Mapped[str | None] = mapped_column(String(80))
    tax_status: Mapped[str | None] = mapped_column(String(80))
    mot_expiry: Mapped[date | None] = mapped_column(Date)
    tax_expiry: Mapped[date | None] = mapped_column(Date)
    last_dvla_lookup_date: Mapped[date | None] = mapped_column(Date)
    mot_source: Mapped[str | None] = mapped_column(String(12))
    mot_expiry_kind: Mapped[str | None] = mapped_column(String(16))
    mot_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    mot_valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    information_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    information_outcome: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    description: Mapped[str | None] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    owner: Mapped[Person | None] = relationship(back_populates="vehicles")
    schedule: Mapped["Schedule | None"] = relationship(back_populates="vehicles")
    events: Mapped[list["AccessEvent"]] = relationship(back_populates="vehicle")
    person_assignments: Mapped[list["VehiclePersonAssignment"]] = relationship(
        back_populates="vehicle",
        cascade="all, delete-orphan",
    )


Index(
    "ix_vehicles_normalized_active_plate",
    func.upper(func.regexp_replace(Vehicle.registration_number, "[^A-Za-z0-9]", "", "g")),
    postgresql_where=Vehicle.is_active.is_(True),
)


class VehiclePersonAssignment(Base, TimestampMixin):
    __tablename__ = "vehicle_person_assignments"

    vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("vehicles.id", ondelete="CASCADE"),
        primary_key=True,
    )
    person_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("people.id", ondelete="CASCADE"),
        primary_key=True,
        index=True,
    )

    vehicle: Mapped[Vehicle] = relationship(back_populates="person_assignments")
    person: Mapped[Person] = relationship(back_populates="vehicle_assignments")


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True, nullable=False)
    first_name: Mapped[str] = mapped_column(String(80), default="", nullable=False)
    last_name: Mapped[str] = mapped_column(String(80), default="", nullable=False)
    full_name: Mapped[str] = mapped_column(String(160), nullable=False)
    profile_photo_data_url: Mapped[str | None] = mapped_column(Text)
    email: Mapped[str | None] = mapped_column(String(255), unique=True, index=True)
    mobile_phone_number: Mapped[str | None] = mapped_column(String(40))
    password_hash: Mapped[str] = mapped_column(Text, nullable=False)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole), default=UserRole.STANDARD, nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    auth_session_version: Mapped[int] = mapped_column(
        Integer, default=0, server_default="0", nullable=False
    )
    password_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    preferences: Mapped[dict[str, Any] | None] = mapped_column(JSONB)

    person: Mapped[Person | None] = relationship()


class SystemSetting(Base, TimestampMixin):
    __tablename__ = "system_settings"

    key: Mapped[str] = mapped_column(String(120), primary_key=True)
    category: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    value: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    is_secret: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)


class MaintenanceModeState(Base, TimestampMixin):
    __tablename__ = "maintenance_mode_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    is_active: Mapped[bool] = mapped_column(
        "is_maintenance_mode_active", Boolean, default=False, nullable=False
    )
    enabled_by: Mapped[str | None] = mapped_column("maintenance_enabled_by", String(160))
    enabled_at: Mapped[datetime | None] = mapped_column(
        "maintenance_enabled_at", DateTime(timezone=True)
    )
    source: Mapped[str | None] = mapped_column(String(80))
    reason: Mapped[str | None] = mapped_column(Text)


class ActionConfirmation(Base, TimestampMixin):
    __tablename__ = "action_confirmations"
    __table_args__ = (UniqueConstraint("token_hash", name="ux_action_confirmations_token_hash"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    action: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    payload_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    actor_user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    target_entity: Mapped[str | None] = mapped_column(String(120), index=True)
    target_id: Mapped[str | None] = mapped_column(String(160), index=True)
    target_label: Mapped[str | None] = mapped_column(String(240))
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    outcome: Mapped[str | None] = mapped_column(String(80), index=True)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column("metadata", JSONB)

    actor_user: Mapped[User] = relationship(foreign_keys=[actor_user_id])


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    category: Mapped[str] = mapped_column(String(80), nullable=False)
    action: Mapped[str] = mapped_column(String(120), nullable=False)
    actor: Mapped[str] = mapped_column(String(160), nullable=False)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    target_entity: Mapped[str | None] = mapped_column(String(120))
    target_id: Mapped[str | None] = mapped_column(String(160))
    target_label: Mapped[str | None] = mapped_column(String(240))
    diff: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column("metadata", JSONB)
    outcome: Mapped[str] = mapped_column(String(80), default="success", nullable=False)
    level: Mapped[str] = mapped_column(String(40), default="info", nullable=False)
    trace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    request_id: Mapped[str | None] = mapped_column(String(80))


Index("ix_audit_logs_timestamp_id", AuditLog.timestamp.desc(), AuditLog.id.desc())
Index(
    "ix_audit_logs_category_timestamp",
    AuditLog.category,
    AuditLog.timestamp.desc(),
    AuditLog.id.desc(),
)
Index(
    "ix_audit_logs_target_entity_timestamp",
    AuditLog.target_entity,
    AuditLog.timestamp.desc(),
    AuditLog.id.desc(),
)
Index(
    "ix_audit_logs_target_entity_target_id_timestamp",
    AuditLog.target_entity,
    AuditLog.target_id,
    AuditLog.timestamp,
    AuditLog.id,
)
Index(
    "ix_audit_logs_level_timestamp", AuditLog.level, AuditLog.timestamp.desc(), AuditLog.id.desc()
)
Index(
    "ix_audit_logs_outcome_timestamp",
    AuditLog.outcome,
    AuditLog.timestamp.desc(),
    AuditLog.id.desc(),
)


class TelemetryTrace(Base):
    __tablename__ = "telemetry_traces"

    trace_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    category: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(40), default="ok", nullable=False)
    level: Mapped[str] = mapped_column(String(40), default="info", nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    duration_ms: Mapped[float | None] = mapped_column(Float)
    actor: Mapped[str | None] = mapped_column(String(160))
    source: Mapped[str | None] = mapped_column(String(120))
    registration_number: Mapped[str | None] = mapped_column(String(32))
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL")
    )
    summary: Mapped[str | None] = mapped_column(Text)
    context: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    error: Mapped[str | None] = mapped_column(Text)


class TelemetrySpan(Base):
    __tablename__ = "telemetry_spans"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    span_id: Mapped[str] = mapped_column(String(16), nullable=False, unique=True, index=True)
    trace_id: Mapped[str] = mapped_column(String(32), nullable=False)
    parent_span_id: Mapped[str | None] = mapped_column(String(16))
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    category: Mapped[str] = mapped_column(String(80), nullable=False)
    step_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    duration_ms: Mapped[float | None] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(40), default="ok", nullable=False)
    attributes: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    input_payload: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    output_payload: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    error: Mapped[str | None] = mapped_column(Text)


Index(
    "ix_telemetry_traces_started_trace",
    TelemetryTrace.started_at.desc(),
    TelemetryTrace.trace_id.desc(),
)
Index(
    "ix_telemetry_traces_category_started",
    TelemetryTrace.category,
    TelemetryTrace.started_at.desc(),
    TelemetryTrace.trace_id.desc(),
)
Index(
    "ix_telemetry_traces_status_started",
    TelemetryTrace.status,
    TelemetryTrace.started_at.desc(),
    TelemetryTrace.trace_id.desc(),
)
Index(
    "ix_telemetry_traces_level_started",
    TelemetryTrace.level,
    TelemetryTrace.started_at.desc(),
    TelemetryTrace.trace_id.desc(),
)
Index(
    "ix_telemetry_traces_access_event_started",
    TelemetryTrace.access_event_id,
    TelemetryTrace.started_at.desc(),
    postgresql_where=TelemetryTrace.access_event_id.is_not(None),
)
Index(
    "ix_telemetry_spans_trace_step_started",
    TelemetrySpan.trace_id,
    TelemetrySpan.step_order,
    TelemetrySpan.started_at,
)


class GateMalfunctionState(Base, TimestampMixin):
    __tablename__ = "gate_malfunction_states"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    gate_entity_id: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    gate_name: Mapped[str | None] = mapped_column(String(160))
    status: Mapped[GateMalfunctionStatus] = mapped_column(
        Enum(GateMalfunctionStatus),
        default=GateMalfunctionStatus.ACTIVE,
        nullable=False,
        index=True,
    )
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    declared_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    fubar_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    fix_attempts_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    next_attempt_scheduled_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), index=True
    )
    attempt_claim_token: Mapped[str | None] = mapped_column(String(64), index=True)
    attempt_claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_known_vehicle_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"), index=True
    )
    telemetry_trace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    last_gate_state: Mapped[str | None] = mapped_column(String(40))
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    last_known_vehicle_event: Mapped["AccessEvent | None"] = relationship()
    timeline_events: Mapped[list["GateMalfunctionTimelineEvent"]] = relationship(
        back_populates="malfunction",
        cascade="all, delete-orphan",
        order_by="GateMalfunctionTimelineEvent.occurred_at",
    )
    notification_outbox: Mapped[list["GateMalfunctionNotificationOutbox"]] = relationship(
        back_populates="malfunction",
        cascade="all, delete-orphan",
        order_by="GateMalfunctionNotificationOutbox.occurred_at",
    )


Index(
    "ux_gate_malfunction_unresolved_gate",
    GateMalfunctionState.gate_entity_id,
    unique=True,
    postgresql_where=GateMalfunctionState.status.in_(
        [GateMalfunctionStatus.ACTIVE, GateMalfunctionStatus.FUBAR]
    ),
)


class GateMalfunctionTimelineEvent(Base, TimestampMixin):
    __tablename__ = "gate_malfunction_timeline_events"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    malfunction_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("gate_malfunction_states.id", ondelete="CASCADE"), nullable=False, index=True
    )
    kind: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(240), nullable=False)
    details: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    attempt_number: Mapped[int | None] = mapped_column(Integer)
    notification_trigger: Mapped[str | None] = mapped_column(String(120), index=True)
    notification_channel: Mapped[str | None] = mapped_column(String(80))
    telemetry_span_id: Mapped[str | None] = mapped_column(String(16), index=True)
    status: Mapped[str] = mapped_column(String(40), default="ok", nullable=False, index=True)

    malfunction: Mapped[GateMalfunctionState] = relationship(back_populates="timeline_events")


class GateMalfunctionNotificationOutbox(Base, TimestampMixin):
    __tablename__ = "gate_malfunction_notification_outbox"
    __table_args__ = (
        UniqueConstraint("malfunction_id", "stage", name="uq_gate_malfunction_notification_stage"),
    )

    recovery_version: Mapped[int | None] = mapped_column(Integer)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    malfunction_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("gate_malfunction_states.id", ondelete="CASCADE"), nullable=False, index=True
    )
    trigger: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    stage: Mapped[str] = mapped_column(String(40), nullable=False, default="initial", index=True)
    subject: Mapped[str] = mapped_column(String(240), nullable=False)
    severity: Mapped[str] = mapped_column(String(40), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    status: Mapped[str] = mapped_column(String(40), default="pending", nullable=False, index=True)
    attempts_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)

    malfunction: Mapped[GateMalfunctionState] = relationship(back_populates="notification_outbox")


class GateStateObservation(Base, TimestampMixin):
    __tablename__ = "gate_state_observations"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    gate_entity_id: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    gate_name: Mapped[str | None] = mapped_column(String(160))
    access_device_id: Mapped[uuid.UUID | None] = mapped_column()
    binding_fingerprint: Mapped[str | None] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    raw_state: Mapped[str | None] = mapped_column(String(80))
    previous_state: Mapped[str | None] = mapped_column(String(40), index=True)
    observed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    state_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    source: Mapped[str] = mapped_column(
        String(80), default="home_assistant", nullable=False, index=True
    )


class NotificationRule(Base, TimestampMixin):
    __tablename__ = "notification_rules"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    trigger_event: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    conditions: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    actions: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    last_fired_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)


Index(
    "ix_notification_rules_trigger_active_created",
    NotificationRule.trigger_event,
    NotificationRule.is_active,
    NotificationRule.created_at.desc(),
)


class NotificationRun(Base, TimestampMixin):
    __tablename__ = "notification_runs"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    # Null identifies historical work; only explicit v1 dispatch is recoverable.
    recovery_version: Mapped[int | None] = mapped_column(Integer)
    claim_token: Mapped[uuid.UUID | None] = mapped_column()
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    delivery_plan: Mapped[list[dict[str, Any]] | None] = mapped_column(JSONB(none_as_null=True))
    rules_override: Mapped[list[dict[str, Any]] | None] = mapped_column(JSONB(none_as_null=True))
    review_reason: Mapped[str | None] = mapped_column(String(120))
    claim_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    trigger_event: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    subject: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(40), default="queued", nullable=False, index=True)
    context: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    delivered_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failures: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    skipped_reasons: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    queued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    error: Mapped[str | None] = mapped_column(Text)


Index("ix_notification_runs_status_queued", NotificationRun.status, NotificationRun.queued_at)
Index(
    "ix_notification_runs_trigger_queued", NotificationRun.trigger_event, NotificationRun.queued_at
)


class NotificationActionContext(Base, TimestampMixin):
    __tablename__ = "notification_action_contexts"
    __table_args__ = (
        UniqueConstraint("token_hash", name="ux_notification_action_contexts_token_hash"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    action: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    notify_service: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    registration_number: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"), index=True
    )
    telemetry_trace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    parent_context_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("notification_action_contexts.id", ondelete="SET NULL"), index=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    outcome: Mapped[str | None] = mapped_column(String(80), index=True)
    outcome_detail: Mapped[str | None] = mapped_column(Text)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column("metadata", JSONB)

    person: Mapped[Person | None] = relationship(foreign_keys=[person_id])
    actor_user: Mapped[User | None] = relationship(foreign_keys=[actor_user_id])
    access_event: Mapped["AccessEvent | None"] = relationship(
        "AccessEvent",
        foreign_keys=[access_event_id],
    )
    parent_context: Mapped["NotificationActionContext | None"] = relationship(
        remote_side=[id],
        foreign_keys=[parent_context_id],
    )


class AutomationRule(Base, TimestampMixin):
    __tablename__ = "automation_rules"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    triggers: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    trigger_keys: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    conditions: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    actions: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_fired_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_run_status: Mapped[str | None] = mapped_column(String(40), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )

    created_by: Mapped[User | None] = relationship()
    runs: Mapped[list["AutomationRun"]] = relationship(
        back_populates="rule",
        passive_deletes=True,
    )


class AutomationRun(Base, TimestampMixin):
    __tablename__ = "automation_runs"
    __table_args__ = (
        UniqueConstraint("occurrence_key", name="uq_automation_run_occurrence"),
        Index(
            "ix_automation_run_recovery_queue",
            "queued_at",
            "id",
            postgresql_where=text("recovery_version = 1 AND status IN ('queued', 'processing')"),
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    rule_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("automation_rules.id", ondelete="SET NULL"),
        index=True,
    )
    trigger_key: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(40), default="running", nullable=False, index=True)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    trigger_payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    context: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    condition_results: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB, default=list, nullable=False
    )
    action_results: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB, default=list, nullable=False
    )
    trace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    error: Mapped[str | None] = mapped_column(Text)
    actor: Mapped[str] = mapped_column(String(160), default="System", nullable=False, index=True)
    source: Mapped[str] = mapped_column(
        String(120), default="automation", nullable=False, index=True
    )
    recovery_version: Mapped[int | None] = mapped_column(Integer)
    occurrence_key: Mapped[str | None] = mapped_column(String(255))
    queued_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    claim_token: Mapped[uuid.UUID | None] = mapped_column()
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    claim_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)
    action_plan: Mapped[list[dict[str, Any]] | None] = mapped_column(JSONB(none_as_null=True))
    review_reason: Mapped[str | None] = mapped_column(String(120))

    rule: Mapped[AutomationRule | None] = relationship(back_populates="runs")


class AutomationWebhookSender(Base, TimestampMixin):
    __tablename__ = "automation_webhook_senders"
    __table_args__ = (
        UniqueConstraint("webhook_key", "source_ip", name="ux_automation_webhook_sender_key_ip"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    webhook_key: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    source_ip: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    first_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    event_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_payload_shape: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    key_strength: Mapped[str] = mapped_column(
        String(40), default="legacy", nullable=False, index=True
    )
    hmac_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    allowed_source_ips: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    last_nonce: Mapped[str | None] = mapped_column(String(160), index=True)
    last_signature_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    rate_window_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), index=True
    )
    rate_window_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rejected_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class AutomationWebhookNonce(Base, TimestampMixin):
    __tablename__ = "automation_webhook_nonces"
    __table_args__ = (
        UniqueConstraint("webhook_key", "nonce_hash", name="ux_automation_webhook_nonce"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    webhook_key: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    source_ip: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    nonce_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    signed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


Index("ix_automation_rules_trigger_keys_gin", AutomationRule.trigger_keys, postgresql_using="gin")
Index("ix_automation_rules_active_next_run", AutomationRule.is_active, AutomationRule.next_run_at)
Index(
    "ix_automation_rules_active_created", AutomationRule.is_active, AutomationRule.created_at.desc()
)
Index("ix_automation_runs_rule_started", AutomationRun.rule_id, AutomationRun.started_at.desc())
Index("ix_automation_webhook_nonces_expires", AutomationWebhookNonce.expires_at)


class LeaderboardState(Base, TimestampMixin):
    __tablename__ = "leaderboard_state"

    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    registration_number: Mapped[str | None] = mapped_column(String(32), index=True)
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="SET NULL"), index=True
    )
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    read_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"), index=True
    )


class Schedule(Base, TimestampMixin):
    __tablename__ = "schedules"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text)
    time_blocks: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)

    people: Mapped[list["Person"]] = relationship(back_populates="schedule")
    vehicles: Mapped[list["Vehicle"]] = relationship(back_populates="schedule")


class ScheduleOverride(Base, TimestampMixin):
    __tablename__ = "schedule_overrides"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    person_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("people.id", ondelete="CASCADE"), index=True, nullable=False
    )
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="CASCADE"), index=True
    )
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True, nullable=False)
    ends_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True, nullable=False)
    reason: Mapped[str | None] = mapped_column(Text)
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    source: Mapped[str] = mapped_column(String(80), default="system", nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)

    person: Mapped[Person] = relationship()
    vehicle: Mapped[Vehicle | None] = relationship()
    created_by: Mapped[User | None] = relationship()


class Presence(Base, TimestampMixin):
    __tablename__ = "presence"

    person_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("people.id", ondelete="CASCADE"), primary_key=True
    )
    state: Mapped[PresenceState] = mapped_column(
        Enum(PresenceState), default=PresenceState.UNKNOWN, nullable=False
    )
    last_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id"), index=True
    )
    last_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    person: Mapped[Person] = relationship(back_populates="presence")


class AccessEvent(Base, TimestampMixin):
    __tablename__ = "access_events"

    resource_revision: Mapped[int] = mapped_column(BigInteger, server_default="0", nullable=False)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="SET NULL"), index=True
    )
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    registration_number: Mapped[str] = mapped_column(String(32), index=True, nullable=False)
    direction: Mapped[AccessDirection] = mapped_column(Enum(AccessDirection), nullable=False)
    decision: Mapped[AccessDecision] = mapped_column(Enum(AccessDecision), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    source: Mapped[str] = mapped_column(String(120), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    timing_classification: Mapped[TimingClassification] = mapped_column(
        Enum(TimingClassification), default=TimingClassification.UNKNOWN, nullable=False
    )
    snapshot_path: Mapped[str | None] = mapped_column(String(512))
    snapshot_content_type: Mapped[str | None] = mapped_column(String(80))
    snapshot_bytes: Mapped[int | None] = mapped_column(Integer)
    snapshot_width: Mapped[int | None] = mapped_column(Integer)
    snapshot_height: Mapped[int | None] = mapped_column(Integer)
    snapshot_captured_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    snapshot_camera: Mapped[str | None] = mapped_column(String(120))
    raw_payload: Mapped[dict[str, Any] | None] = mapped_column(JSONB)

    vehicle: Mapped[Vehicle | None] = relationship(back_populates="events")
    anomalies: Mapped[list["Anomaly"]] = relationship(back_populates="event")
    movement_sagas: Mapped[list["MovementSagaRecord"]] = relationship(back_populates="access_event")


Index("ix_access_events_created_at", AccessEvent.created_at)
Index(
    "ix_access_events_decision_occurred_person_vehicle",
    AccessEvent.decision,
    AccessEvent.occurred_at.desc(),
    AccessEvent.person_id,
    AccessEvent.vehicle_id,
)
Index(
    "ix_access_events_snapshot_created_at",
    AccessEvent.created_at,
    postgresql_where=AccessEvent.snapshot_path.is_not(None),
)
Index(
    "ix_access_events_snapshot_registration_occurred",
    AccessEvent.registration_number,
    AccessEvent.occurred_at.desc(),
    postgresql_where=AccessEvent.snapshot_path.is_not(None)
    & AccessEvent.snapshot_bytes.is_not(None),
)
Index(
    "ix_access_events_granted_person_direction_time",
    AccessEvent.person_id,
    AccessEvent.direction,
    AccessEvent.occurred_at.desc(),
    postgresql_where=(
        (AccessEvent.decision == AccessDecision.GRANTED)
        & AccessEvent.person_id.is_not(None)
        & AccessEvent.direction.in_([AccessDirection.ENTRY, AccessDirection.EXIT])
    ),
)
Index(
    "ix_access_events_granted_vehicle_direction_time",
    AccessEvent.vehicle_id,
    AccessEvent.direction,
    AccessEvent.occurred_at.desc(),
    postgresql_where=(
        (AccessEvent.decision == AccessDecision.GRANTED)
        & AccessEvent.vehicle_id.is_not(None)
        & AccessEvent.direction.in_([AccessDirection.ENTRY, AccessDirection.EXIT])
    ),
)


class LprZoneShadowObservation(Base, TimestampMixin):
    __tablename__ = "lpr_zone_shadow_observations"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    registration_number: Mapped[str] = mapped_column(String(32), index=True, nullable=False)
    detected_registration_number: Mapped[str | None] = mapped_column(String(32), index=True)
    source: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    protect_event_id: Mapped[str | None] = mapped_column(String(160), index=True)
    camera_id: Mapped[str | None] = mapped_column(String(120), index=True)
    camera_name: Mapped[str | None] = mapped_column(String(160))
    camera_identifier: Mapped[str | None] = mapped_column(String(160))
    observed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    time_of_day: Mapped[str] = mapped_column(
        String(20), default="unknown", nullable=False, index=True
    )
    time_of_day_source: Mapped[str] = mapped_column(String(80), default="unknown", nullable=False)
    zone_id: Mapped[str | None] = mapped_column(String(120), index=True)
    zone_name: Mapped[str | None] = mapped_column(String(160), index=True)
    zone_status: Mapped[str | None] = mapped_column(String(40), index=True)
    zone_level: Mapped[float | None] = mapped_column(Float)
    actual_decision: Mapped[str | None] = mapped_column(String(80), index=True)
    actual_direction: Mapped[str | None] = mapped_column(String(40), index=True)
    actual_outcome: Mapped[str | None] = mapped_column(String(80), index=True)
    shadow_decision: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    shadow_reason: Mapped[str] = mapped_column(Text, default="", nullable=False)
    would_suppress: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    details: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)

    access_event: Mapped[AccessEvent | None] = relationship()


Index("ix_lpr_zone_shadow_observed_at", LprZoneShadowObservation.observed_at.desc())
Index(
    "ix_lpr_zone_shadow_plate_observed",
    LprZoneShadowObservation.registration_number,
    LprZoneShadowObservation.observed_at.desc(),
)
Index(
    "ix_lpr_zone_shadow_status_observed",
    LprZoneShadowObservation.zone_status,
    LprZoneShadowObservation.observed_at.desc(),
)
Index(
    "ix_lpr_zone_shadow_decision_observed",
    LprZoneShadowObservation.shadow_decision,
    LprZoneShadowObservation.observed_at.desc(),
)


class LprIngestEvent(Base, TimestampMixin):
    __tablename__ = "lpr_ingest_events"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    idempotency_key: Mapped[str] = mapped_column(
        String(180), unique=True, nullable=False, index=True
    )
    source: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    registration_number: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    captured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    observation_state: Mapped[str] = mapped_column(String(32), server_default="legacy_terminal", nullable=False)
    original_observation: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    observation_completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    capture_token: Mapped[uuid.UUID | None] = mapped_column()
    capture_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ready_ordinal: Mapped[int | None] = mapped_column(BigInteger, unique=True)
    lease_token: Mapped[uuid.UUID | None] = mapped_column()
    lease_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    window_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lpr_debounce_windows.id", ondelete="RESTRICT", use_alter=True, name="fk_lpr_ingest_window"))
    terminal_reason: Mapped[str | None] = mapped_column(String(120))
    normalized_payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    status: Mapped[str] = mapped_column(String(40), default="pending", nullable=False, index=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    processing_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), index=True
    )
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    movement_saga_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("movement_sagas.id", ondelete="SET NULL"),
        index=True,
    )
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )

    movement_saga: Mapped["MovementSagaRecord | None"] = relationship()
    access_event: Mapped[AccessEvent | None] = relationship()


Index("ix_lpr_ingest_events_status_received", LprIngestEvent.status, LprIngestEvent.received_at)
Index("ix_lpr_ingest_events_source_captured", LprIngestEvent.source, LprIngestEvent.captured_at)


class MovementSagaRecord(Base, TimestampMixin):
    __tablename__ = "movement_sagas"
    __table_args__ = (
        CheckConstraint(
            "admission_status IS NULL OR admission_status IN ('pending','verified','not_required','denied','historical')",
            name="ck_movement_sagas_admission_status",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    idempotency_key: Mapped[str] = mapped_column(
        String(160), unique=True, nullable=False, index=True
    )
    source: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    state: Mapped[MovementSagaState] = mapped_column(
        Enum(MovementSagaState),
        default=MovementSagaState.OBSERVED,
        nullable=False,
        index=True,
    )
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="SET NULL"), index=True
    )
    registration_number: Mapped[str | None] = mapped_column(String(32), index=True)
    direction: Mapped[AccessDirection | None] = mapped_column(Enum(AccessDirection), index=True)
    decision: Mapped[AccessDecision | None] = mapped_column(Enum(AccessDecision), index=True)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    gate_command_required: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False, index=True
    )
    presence_committed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # NULL is unclassified legacy history, never proof of entry admission.
    admission_status: Mapped[str | None] = mapped_column(String(24))
    admission_evidence: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    reconciliation_required: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False, index=True
    )
    failure_detail: Mapped[str | None] = mapped_column(Text)
    intent_payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    decision_payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    state_history: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)

    access_event: Mapped[AccessEvent | None] = relationship(back_populates="movement_sagas")
    gate_commands: Mapped[list["GateCommandRecord"]] = relationship(back_populates="movement_saga")


class GateCommandRecord(Base, TimestampMixin):
    __tablename__ = "gate_command_records"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    idempotency_key: Mapped[str] = mapped_column(
        String(180), unique=True, nullable=False, index=True
    )
    movement_saga_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("movement_sagas.id", ondelete="SET NULL"),
        index=True,
    )
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    state: Mapped[GateCommandState] = mapped_column(
        Enum(GateCommandState),
        default=GateCommandState.PENDING,
        nullable=False,
        index=True,
    )
    action: Mapped[str] = mapped_column(String(40), default="open", nullable=False)
    source: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    gate_key: Mapped[str] = mapped_column(
        String(120), default="default", nullable=False, index=True
    )
    controller: Mapped[str] = mapped_column(String(80), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    actor: Mapped[str | None] = mapped_column(String(160))
    registration_number: Mapped[str | None] = mapped_column(String(32), index=True)
    bypass_schedule: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    lease_token: Mapped[str | None] = mapped_column(String(80), index=True)
    leased_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    accepted: Mapped[bool | None] = mapped_column(Boolean)
    gate_state: Mapped[str | None] = mapped_column(String(40))
    detail: Mapped[str | None] = mapped_column(Text)
    mechanically_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requires_reconciliation: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False, index=True
    )
    exception_class: Mapped[str | None] = mapped_column(String(120))
    command_metadata: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)

    movement_saga: Mapped[MovementSagaRecord | None] = relationship(back_populates="gate_commands")


class AccessDeviceCommandRecord(Base, TimestampMixin):
    """Journal owns transport truth; access delivery owns its output checkpoint."""

    __tablename__ = "access_device_command_records"
    __table_args__ = (
        CheckConstraint("action IN ('open', 'close')", name="ck_device_command_action"),
        CheckConstraint(
            "state IN ('prepared', 'attempting', 'accepted', 'rejected', 'unknown', 'verified', 'not_sent')",
            name="ck_device_command_state",
        ),
        UniqueConstraint("idempotency_key", name="uq_device_command_idempotency"),
        Index(
            "uq_device_command_unresolved_target",
            "target_device_id",
            unique=True,
            postgresql_where=text("state IN ('prepared', 'attempting', 'accepted', 'unknown')"),
        ),
        Index("ix_device_command_parent_state", "gate_command_id", "state"),
        Index("ix_device_command_state_lease", "state", "lease_expires_at"),
        CheckConstraint(
            "origin_context IS NULL OR (jsonb_typeof(origin_context) = 'object' AND COALESCE(origin_context->>'kind' = 'automatic_access_garage', FALSE))",
            name="ck_device_command_origin",
        ),
        CheckConstraint(
            "outcome_recorded_at IS NULL OR origin_context IS NOT NULL",
            name="ck_device_command_output_origin",
        ),
        Index(
            "ix_device_command_pending_output",
            "created_at",
            "id",
            postgresql_where=text("origin_context IS NOT NULL AND outcome_recorded_at IS NULL"),
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    gate_command_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("gate_command_records.id", ondelete="SET NULL")
    )
    # Immutable historical identity: deleting a terminal device must not erase receipts.
    target_device_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    device_key: Mapped[str] = mapped_column(String(120), nullable=False)
    action: Mapped[str] = mapped_column(String(40), nullable=False)
    intent_id: Mapped[str] = mapped_column(String(80), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(180), nullable=False)
    recovery_version: Mapped[int] = mapped_column(
        Integer, default=1, server_default="1", nullable=False
    )
    state: Mapped[str] = mapped_column(String(32), nullable=False)
    binding_snapshot: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    binding_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    lease_token: Mapped[str | None] = mapped_column(String(80))
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    attempted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    accepted: Mapped[bool | None] = mapped_column(Boolean)
    gate_state: Mapped[str | None] = mapped_column(String(40))
    verification_observation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("gate_state_observations.id", ondelete="SET NULL")
    )
    verification_evidence: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    provider_receipts: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB, default=list, server_default=text("'[]'::jsonb"), nullable=False
    )
    detail: Mapped[str | None] = mapped_column(Text)
    origin_context: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    outcome_recorded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MovementSessionRecord(Base, TimestampMixin):
    __tablename__ = "movement_sessions"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    session_key: Mapped[str] = mapped_column(String(220), unique=True, nullable=False, index=True)
    source: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    access_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    movement_saga_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("movement_sagas.id", ondelete="SET NULL"),
        index=True,
    )
    registration_number: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    normalized_registration_number: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    direction: Mapped[AccessDirection] = mapped_column(
        Enum(AccessDirection), nullable=False, index=True
    )
    decision: Mapped[AccessDecision] = mapped_column(
        Enum(AccessDecision), nullable=False, index=True
    )
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    debounce_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), index=True
    )
    gate_cycle_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), index=True
    )
    idle_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    camera_id: Mapped[str | None] = mapped_column(String(120), index=True)
    device_id: Mapped[str | None] = mapped_column(String(120), index=True)
    protect_event_ids: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    ocr_variants: Mapped[list[str]] = mapped_column(JSONB, default=list, nullable=False)
    last_gate_state: Mapped[str | None] = mapped_column(String(40))
    suppressed_read_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_suppressed_reason: Mapped[str | None] = mapped_column(String(160), index=True)
    last_matched_by: Mapped[str | None] = mapped_column(String(80))
    last_presence_evidence: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    suppressed_reads: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB, default=list, nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)


Index("ix_movement_sagas_state_updated_at", MovementSagaRecord.state, MovementSagaRecord.updated_at)
Index(
    "ix_movement_sagas_reconciliation_updated_at",
    MovementSagaRecord.reconciliation_required,
    MovementSagaRecord.updated_at,
)
Index(
    "ix_gate_command_records_gate_state_lease",
    GateCommandRecord.gate_key,
    GateCommandRecord.state,
    GateCommandRecord.lease_expires_at,
)
Index(
    "ix_gate_command_records_reconciliation_updated",
    GateCommandRecord.requires_reconciliation,
    GateCommandRecord.updated_at,
)
Index(
    "ix_movement_sessions_source_last_seen",
    MovementSessionRecord.source,
    MovementSessionRecord.last_seen_at,
)
Index(
    "ix_movement_sessions_source_gate_cycle",
    MovementSessionRecord.source,
    MovementSessionRecord.gate_cycle_expires_at,
)
Index(
    "ix_movement_sessions_active_idle",
    MovementSessionRecord.is_active,
    MovementSessionRecord.idle_expires_at,
)


class ReportExport(Base, TimestampMixin):
    __tablename__ = "report_exports"
    __table_args__ = (
        UniqueConstraint("report_number", name="ux_report_exports_report_number"),
        Index("ix_report_exports_person_created", "person_id", "created_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    report_number: Mapped[str] = mapped_column(String(12), nullable=False)
    report_type: Mapped[str] = mapped_column(
        String(80), default="person_movements", nullable=False, index=True
    )
    person_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"),
        index=True,
    )
    period_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    period_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    options: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    snapshot: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    pdf_path: Mapped[str] = mapped_column(String(512), nullable=False)
    pdf_bytes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True,
    )

    person: Mapped[Person | None] = relationship()
    created_by: Mapped[User | None] = relationship()


class VisitorPass(Base, TimestampMixin):
    __tablename__ = "visitor_passes"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    visitor_name: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    pass_type: Mapped[VisitorPassType] = mapped_column(
        Enum(VisitorPassType, native_enum=False, length=20),
        default=VisitorPassType.ONE_TIME,
        nullable=False,
        index=True,
    )
    visitor_phone: Mapped[str | None] = mapped_column(String(40), index=True)
    expected_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    window_minutes: Mapped[int] = mapped_column(Integer, default=30, nullable=False)
    valid_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    status: Mapped[VisitorPassStatus] = mapped_column(
        Enum(VisitorPassStatus),
        default=VisitorPassStatus.SCHEDULED,
        nullable=False,
        index=True,
    )
    creation_source: Mapped[str] = mapped_column(
        String(80), default="ui", nullable=False, index=True
    )
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True,
    )
    arrival_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    departure_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    number_plate: Mapped[str | None] = mapped_column(String(32), index=True)
    vehicle_make: Mapped[str | None] = mapped_column(String(80))
    vehicle_colour: Mapped[str | None] = mapped_column(String(80))
    duration_on_site_seconds: Mapped[int | None] = mapped_column(Integer)
    arrival_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    departure_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL"),
        index=True,
    )
    telemetry_trace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    source_reference: Mapped[str | None] = mapped_column(String(255), index=True)
    source_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB)

    created_by: Mapped[User | None] = relationship()
    arrival_event: Mapped[AccessEvent | None] = relationship(foreign_keys=[arrival_event_id])
    departure_event: Mapped[AccessEvent | None] = relationship(foreign_keys=[departure_event_id])


class VisitorPassReservationRecord(Base, TimestampMixin):
    """Immutable arrival identity; reservation settlement owns consumption.

    Historical IDs intentionally survive event/pass retention. The visitor owner
    refuses destructive mutation while a reservation is unresolved.
    """

    __tablename__ = "visitor_pass_reservations"
    __table_args__ = (
        UniqueConstraint("access_event_id", name="uq_visitor_reservation_event"),
        UniqueConstraint("intent_id", name="uq_visitor_reservation_intent"),
        CheckConstraint(
            "state IN ('reserved','held','consumed','released')",
            name="ck_visitor_reservation_state",
        ),
        CheckConstraint(
            "pass_type IN ('one-time','duration')", name="ck_visitor_reservation_pass_type"
        ),
    )
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    visitor_pass_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    access_event_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    intent_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    gate_command_id: Mapped[uuid.UUID | None] = mapped_column()
    pass_type: Mapped[str] = mapped_column(String(20), nullable=False)
    normalized_plate: Mapped[str] = mapped_column(String(32), nullable=False)
    state: Mapped[str] = mapped_column(String(20), default="reserved", nullable=False)
    dispatch_deadline: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completion_reason: Mapped[str | None] = mapped_column(Text)
    verification_evidence: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))


Index(
    "uq_visitor_reservation_unavailable",
    VisitorPassReservationRecord.visitor_pass_id,
    unique=True,
    postgresql_where=text(
        "state IN ('reserved','held') OR (state = 'consumed' AND pass_type = 'one-time')"
    ),
)
Index(
    "ix_visitor_reservation_state_deadline",
    VisitorPassReservationRecord.state,
    VisitorPassReservationRecord.dispatch_deadline,
)


Index(
    "ux_visitor_passes_source_reference",
    VisitorPass.source_reference,
    unique=True,
    postgresql_where=VisitorPass.source_reference.is_not(None),
)
Index("ix_visitor_passes_status_expected_time", VisitorPass.status, VisitorPass.expected_time)
Index("ix_visitor_passes_number_plate_status", VisitorPass.number_plate, VisitorPass.status)
Index("ix_visitor_passes_visitor_phone_status", VisitorPass.visitor_phone, VisitorPass.status)
Index("ix_visitor_passes_status_valid_until", VisitorPass.status, VisitorPass.valid_until)
Index(
    "ix_visitor_passes_duration_phone_window",
    VisitorPass.visitor_phone,
    VisitorPass.status,
    VisitorPass.valid_from,
    VisitorPass.valid_until,
    postgresql_where=(
        (VisitorPass.pass_type == VisitorPassType.DURATION) & VisitorPass.visitor_phone.is_not(None)
    ),
)
Index(
    "ix_visitor_passes_open_departure_lookup",
    VisitorPass.number_plate,
    VisitorPass.arrival_time.desc(),
    VisitorPass.created_at.desc(),
    postgresql_where=(
        or_(
            VisitorPass.status == VisitorPassStatus.USED,
            (
                (VisitorPass.pass_type == VisitorPassType.DURATION)
                & (VisitorPass.status == VisitorPassStatus.ACTIVE)
            ),
        )
        & VisitorPass.departure_time.is_(None)
        & VisitorPass.arrival_time.is_not(None)
        & VisitorPass.number_plate.is_not(None)
    ),
)
Index(
    "ix_visitor_passes_calendar_active_source",
    VisitorPass.creation_source,
    VisitorPass.source_reference,
    VisitorPass.status,
    postgresql_where=(
        (VisitorPass.creation_source == "icloud_calendar")
        & VisitorPass.status.in_([VisitorPassStatus.SCHEDULED, VisitorPassStatus.ACTIVE])
        & VisitorPass.source_reference.is_not(None)
    ),
)


class ICloudCalendarAccount(Base, TimestampMixin):
    __tablename__ = "icloud_calendar_accounts"
    __table_args__ = (
        CheckConstraint("sync_generation >= 0", name="ck_icloud_calendar_sync_generation"),
        CheckConstraint("(sync_lease_token IS NULL) = (sync_lease_until IS NULL)", name="ck_icloud_calendar_sync_lease_pair"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    apple_id: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    display_name: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(40), default="connected", nullable=False, index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    encrypted_session_bundle: Mapped[str | None] = mapped_column(Text)
    sync_generation: Mapped[int] = mapped_column(BigInteger, server_default="0", nullable=False)
    sync_lease_token: Mapped[uuid.UUID | None] = mapped_column()
    sync_lease_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_auth_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_sync_status: Mapped[str | None] = mapped_column(String(40), index=True)
    last_sync_summary: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    last_error: Mapped[str | None] = mapped_column(Text)
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True,
    )

    created_by: Mapped[User | None] = relationship()


class ICloudCalendarSyncRun(Base, TimestampMixin):
    __tablename__ = "icloud_calendar_sync_runs"

    # Empty marks historical rows; only the typed v1 owner can resume new context.
    run_context: Mapped[dict[str, Any]] = mapped_column(
        JSONB, default=dict, server_default=text("'{}'::jsonb"), nullable=False
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    status: Mapped[str] = mapped_column(String(40), default="running", nullable=False, index=True)
    trigger_source: Mapped[str] = mapped_column(
        String(80), default="ui", nullable=False, index=True
    )
    triggered_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True,
    )
    account_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    events_scanned: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    events_matched: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    passes_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    passes_updated: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    passes_cancelled: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    passes_skipped: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    account_results: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB, default=list, nullable=False
    )
    error: Mapped[str | None] = mapped_column(Text)

    triggered_by: Mapped[User | None] = relationship()


class Anomaly(Base, TimestampMixin):
    __tablename__ = "anomalies"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="CASCADE"), index=True
    )
    anomaly_type: Mapped[AnomalyType] = mapped_column(Enum(AnomalyType), nullable=False, index=True)
    severity: Mapped[AnomalySeverity] = mapped_column(
        Enum(AnomalySeverity), nullable=False, index=True
    )
    message: Mapped[str] = mapped_column(Text, nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    resolved_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    resolution_note: Mapped[str | None] = mapped_column(Text)
    context: Mapped[dict[str, Any] | None] = mapped_column(JSONB)

    event: Mapped[AccessEvent | None] = relationship(back_populates="anomalies")
    resolved_by: Mapped[User | None] = relationship()


Index("ix_anomalies_created_at", Anomaly.created_at)
Index(
    "ix_anomalies_open_created_at",
    Anomaly.created_at.desc(),
    postgresql_where=Anomaly.resolved_at.is_(None),
)


class RevokedAuthToken(Base, TimestampMixin):
    __tablename__ = "revoked_auth_tokens"
    __table_args__ = (UniqueConstraint("jti_hash", name="ux_revoked_auth_tokens_jti_hash"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    jti_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )


class ResidentRecoveryJourney(Base, TimestampMixin):
    """Bounded distance evidence, not a resident's raw location history."""

    __tablename__ = "resident_recovery_journeys"
    person_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("people.id", ondelete="CASCADE"), primary_key=True
    )
    epoch: Mapped[str] = mapped_column(String(36), nullable=False)
    binding: Mapped[str] = mapped_column(String(64), nullable=False)
    coordinate_hash: Mapped[str | None] = mapped_column(String(64))
    latest_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    samples: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    invalid_reason: Mapped[str | None] = mapped_column(String(80))
    claimed_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL")
    )
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MissedExitRecoveryAttempt(Base, TimestampMixin):
    __tablename__ = "missed_exit_recovery_attempts"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    owner_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("people.id", ondelete="SET NULL"), index=True
    )
    owner_name: Mapped[str] = mapped_column(String(160), nullable=False)
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="SET NULL")
    )
    registration_number: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    event_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("access_events.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    saga_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("movement_sagas.id", ondelete="SET NULL")
    )
    recovery_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("access_events.id", ondelete="SET NULL")
    )
    command_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("gate_command_records.id", ondelete="SET NULL")
    )
    action_context_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("notification_action_contexts.id", ondelete="SET NULL")
    )
    method: Mapped[str] = mapped_column(String(40), default="none", nullable=False, index=True)
    outcome: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    reason: Mapped[str] = mapped_column(String(120), nullable=False)
    policy_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    checks: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    timeline: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, default=list, nullable=False)
    notification: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict, nullable=False)
    duration_ms: Mapped[float | None] = mapped_column(Float)

Index("ix_lpr_ingest_observing", LprIngestEvent.observation_state, LprIngestEvent.capture_until, LprIngestEvent.id)
Index("ix_lpr_ingest_ready_order", LprIngestEvent.status, LprIngestEvent.ready_ordinal)
Index("ix_lpr_ingest_window", LprIngestEvent.window_id, LprIngestEvent.id)
