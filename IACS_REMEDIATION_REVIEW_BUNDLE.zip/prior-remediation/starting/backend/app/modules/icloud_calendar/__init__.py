"""iCloud Calendar integration boundary."""
