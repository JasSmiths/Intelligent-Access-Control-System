from datetime import UTC, datetime, timedelta
import hashlib
import hmac
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, Mock
import uuid

from fastapi import HTTPException
import pytest
from sqlalchemy.exc import IntegrityError
from starlette.requests import Request

from app.api.v1 import automations as automations_api
from app.models import AutomationRule, AutomationRun, Presence
from app.models.enums import PresenceState, UserRole
from app.services import automations, automation_webhooks, automation_errors
from app.services.automations import AutomationService
from app.services.automation_scheduling import cron_from_recurrence, due_time_trigger, next_run_for_trigger
from app.services.workflows.automation_definition import (
    ACTION_CATALOG, CONDITION_CATALOG, TRIGGER_CATALOG, AutomationContext, build_context_variables, context_missing_references, facts_from_payload, normalize_actions, normalize_conditions, normalize_triggers, trigger_keys_for_triggers,
    automation_triggers_for_origin, generate_automation_webhook_key, is_high_entropy_webhook_key,
)
from app.services.automation_intake import public_automation_context, automation_execution_context_snapshot


def make_request(
    method: str,
    path: str,
    *,
    body: bytes = b"",
    headers: list[tuple[bytes, bytes]] | None = None,
) -> Request:
    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}

    return Request(
        {
            "type": "http",
            "method": method,
            "path": path,
            "query_string": b"",
            "headers": headers or [],
        },
        receive,
    )


def test_automation_registries_expose_required_keys() -> None:
    trigger_keys = {item["type"] for group in TRIGGER_CATALOG for item in group["triggers"]}
    condition_keys = {item["type"] for group in CONDITION_CATALOG for item in group["conditions"]}
    action_keys = {item["type"] for group in ACTION_CATALOG for item in group["actions"]}

    assert {
        "time.specific_datetime",
        "time.every_x",
        "time.cron",
        "vehicle.known_plate",
        "vehicle.unknown_plate",
        "vehicle.outside_schedule",
        "maintenance_mode.enabled",
        "maintenance_mode.disabled",
        "visitor_pass.created",
        "visitor_pass.detected",
        "visitor_pass.used",
        "visitor_pass.expired",
        "webhook.received",
        "webhook.unrecognized",
        "webhook.new_sender",
    }.issubset(trigger_keys)
    assert {
        "person.on_site",
        "person.off_site",
        "vehicle.on_site",
        "vehicle.off_site",
        "maintenance_mode.enabled",
        "maintenance_mode.disabled",
    }.issubset(condition_keys)
    assert {
        "notification.enable",
        "notification.disable",
        "gate.open",
        "garage_door.open",
        "garage_door.close",
        "maintenance_mode.enable",
        "maintenance_mode.disable",
    }.issubset(action_keys)


def test_automation_evidence_helpers_preserve_config_and_dispatch_truth() -> None:
    rule = AutomationRule(
        id=uuid.UUID("11111111-1111-1111-1111-111111111111"),
        name="Open main garage door on arrival",
        is_active=True,
        triggers=[{"type": "vehicle.known_plate", "config": {"webhook_key": "secret"}}],
        trigger_keys=["vehicle.known_plate"],
        conditions=[{"id": "schedule", "type": "schedule.allowed", "config": {}}],
        actions=[{"id": "open", "type": "garage_door.open", "config": {}}],
    )
    context = AutomationContext(
        trigger_key="vehicle.known_plate",
        subject="Main Garage Door",
        trigger_payload={"registration_number": "IACS1"},
    )

    snapshot = automation_execution_context_snapshot(
        context,
        rule,
        captured_at=datetime(2026, 7, 14, 21, 47, tzinfo=UTC),
    )
    stored_rule = snapshot["configuration_snapshot"]["rule"]

    assert stored_rule["name"] == "Open main garage door on arrival"
    assert stored_rule["triggers"][0]["config"]["webhook_key"] == "[redacted]"
    blocked_result = {
        "status": "skipped",
        "outcomes": [
            {
                "accepted": False,
                "attempts": [],
                "metadata": {
                    "schedule_evaluation": {
                        "allowed": False,
                        "reason_code": "schedule_outside_window",
                    }
                },
            }
        ],
    }
    rejected_result = {
        "status": "failed",
        "outcomes": [{"accepted": False, "attempts": [{"provider": "esphome"}]}],
    }

    assert (
        automations.automation_condition_reason_code(
            {"passed": False, "reason": "Current configuration did not match."},
            {"type": "schedule.allowed"},
        )
        == "schedule_allowed_failed"
    )


@pytest.mark.asyncio
async def test_automation_rule_create_requires_confirmation_before_write() -> None:
    with pytest.raises(HTTPException) as exc:
        await automations_api.create_automation_rule(
            automations_api.AutomationRuleRequest(
                name="Open gate",
                triggers=[{"type": "vehicle.known_plate", "config": {}}],
                actions=[{"type": "gate.open", "config": {}, "reason_template": "@Subject"}],
            ),
            user=SimpleNamespace(id=uuid.uuid4()),
            session=SimpleNamespace(),
        )

    assert exc.value.status_code == 428


def test_automation_schema_normalization_shapes_payloads() -> None:
    triggers = normalize_triggers(
        [
            {"type": "vehicle.outside_schedule", "config": {"person_id": "person-1", "ignored": True}},
            {"type": "not.allowed", "config": {}},
        ]
    )
    conditions = normalize_conditions(
        [{"type": "person.on_site", "config": {"person_id": "person-1", "extra": "ignored"}}]
    )
    actions = normalize_actions(
        [
            {
                "type": "garage_door.open",
                "config": {"target_entity_ids": ["cover.left", ""]},
                "reason_template": "@DisplayName arrived.",
            }
        ]
    )

    assert trigger_keys_for_triggers(triggers) == ["vehicle.outside_schedule"]
    assert triggers[0]["config"] == {"person_id": "person-1"}
    assert conditions[0]["config"] == {"person_id": "person-1"}
    assert actions[0]["config"] == {"target_entity_ids": ["cover.left"]}
    assert actions[0]["reason_template"] == "@DisplayName arrived."




def test_missing_variable_references_skip_unavailable_trigger_scopes() -> None:
    context = AutomationContext(
        trigger_key="time.cron",
        subject="Schedule tick",
        trigger_payload={},
        facts={"occurred_at": "2026-04-30T20:15:00+01:00"},
        scopes={"time", "event"},
    )
    context.variables = build_context_variables(context)

    missing = context_missing_references(
        context,
        {"reason_template": "Open for @VisitorPassVehicleRegistration"},
    )

    assert missing == ["VisitorPassVehicleRegistration"]
    assert public_automation_context(context)["missing_required_variables"] == ["VisitorPassVehicleRegistration"]
    assert "not available" in context.warnings[0]


def test_missing_unknown_variable_references_skip_cleanly() -> None:
    context = AutomationContext(
        trigger_key="vehicle.known_plate",
        subject="Known plate",
        trigger_payload={},
        facts={"registration_number": "AB12 CDE"},
        scopes={"vehicle", "event"},
    )
    context.variables = build_context_variables(context)

    missing = context_missing_references(context, {"reason_template": "Open for @UnknownVariable"})

    assert missing == ["UnknownVariable"]
    assert public_automation_context(context)["missing_required_variables"] == ["UnknownVariable"]
    assert "Unknown variable @UnknownVariable" in context.warnings[0]


def test_event_bridge_uses_direct_access_event_domain_events() -> None:
    created_at = "2026-04-30T20:15:00+00:00"

    known = automation_triggers_for_origin(
        "access_event.finalized", {"decision": "granted", "vehicle_id": "vehicle-1", "occurred_at": created_at},
        occurred_at=created_at,
    )
    outside_schedule = automation_triggers_for_origin(
        "access_event.finalized", {"decision": "denied", "vehicle_id": "vehicle-1", "occurred_at": created_at},
        occurred_at=created_at,
    )
    unknown = automation_triggers_for_origin(
        "access_event.finalized", {"decision": "denied", "registration_number": "AB12 CDE", "occurred_at": created_at},
        occurred_at=created_at,
    )
    backfilled = automation_triggers_for_origin(
        "access_event.finalized", {"decision": "granted", "vehicle_id": "vehicle-1", "occurred_at": created_at, "backfilled": True},
        occurred_at=created_at,
    )

    assert known[0][0] == "vehicle.known_plate"
    assert outside_schedule[0][0] == "vehicle.outside_schedule"
    assert unknown[0][0] == "vehicle.unknown_plate"
    assert backfilled == []


def test_event_bridge_ignores_notification_and_automation_status_events() -> None:
    for event_type in (
        "notification.trigger",
        "notification.sent",
        "notification.failed",
        "notification.skipped",
        "automation.run.success",
        "automation.run.failed",
        "automation.run.skipped",
    ):
        assert automation_triggers_for_origin(
            event_type, {"event_type": "unauthorized_plate"},
            occurred_at="2026-04-30T20:15:00+00:00",
        ) == []


@pytest.mark.asyncio
async def test_person_condition_evaluation_uses_presence_state() -> None:
    person_id = "11111111-1111-1111-1111-111111111111"

    class Session:
        async def get(self, model, _id, **kwargs):
            assert model is Presence
            return SimpleNamespace(state=PresenceState.PRESENT)

    context = AutomationContext(
        trigger_key="vehicle.known_plate",
        subject="Steph arrived",
        trigger_payload={},
        facts={"person_id": person_id},
        entities={"person_id": person_id},
        scopes={"person", "vehicle", "event"},
    )
    context.variables = build_context_variables(context)

    result = await AutomationService()._evaluate_condition(
        Session(),
        {"id": "condition-1", "type": "person.on_site", "config": {}},
        context,
    )

    assert result["passed"] is True
    assert result["details"]["person_id"] == person_id


@pytest.mark.asyncio
async def test_maintenance_mode_skips_actions_but_allows_disable(monkeypatch) -> None:
    async def active() -> bool:
        return True

    async def set_mode(active_state, **_kwargs):
        return {"is_active": active_state}

    monkeypatch.setattr(automations, "is_maintenance_mode_active", active)
    monkeypatch.setattr(automations, "set_maintenance_mode", set_mode)
    service = AutomationService()
    rule: Any = SimpleNamespace(name="Nightly reset")
    context = AutomationContext(
        trigger_key="time.cron",
        subject="Schedule tick",
        trigger_payload={},
        scopes={"time", "event", "maintenance"},
    )
    context.variables = build_context_variables(context)

    skipped = await service._execute_action(
        SimpleNamespace(),
        {"id": "action-1", "type": "gate.open", "config": {}, "reason_template": ""},
        context,
        rule=rule,
    )
    allowed = await service._execute_action(
        SimpleNamespace(),
        {"id": "action-2", "type": "maintenance_mode.disable", "config": {}, "reason_template": ""},
        context,
        rule=rule,
    )

    assert skipped["status"] == "skipped"
    assert skipped["reason"] == "maintenance_mode"
    assert allowed["status"] == "success"
    assert allowed["maintenance_mode"]["is_active"] is False














def test_scheduler_next_run_and_due_trigger_helpers() -> None:
    now = datetime(2026, 4, 30, 12, 0, tzinfo=UTC)
    every_x = {"id": "trigger-1", "type": "time.every_x", "config": {"interval": 15, "unit": "minutes"}}
    weekly_start = datetime(2026, 4, 30, 21, 0, tzinfo=UTC)

    assert next_run_for_trigger(every_x, now=now) == now + timedelta(minutes=15)
    due_trigger = due_time_trigger([every_x], now=now, scheduled_for=now)
    assert due_trigger is not None
    assert due_trigger["id"] == "trigger-1"
    assert cron_from_recurrence(weekly_start, "weekly") == "0 21 * * 4"


def test_malformed_every_x_interval_defaults_safely() -> None:
    now = datetime(2026, 4, 30, 12, 0, tzinfo=UTC)
    trigger = normalize_triggers(
        [{"type": "time.every_x", "config": {"interval": "not-a-number", "unit": "hours"}}]
    )[0]

    assert trigger["config"]["interval"] == 1
    assert next_run_for_trigger(trigger, now=now) == now + timedelta(hours=1)


def test_webhook_payload_facts_capture_sender_and_shape_message() -> None:
    facts = facts_from_payload(
        "webhook.received",
        {
            "webhook_key": "hook-key",
            "source_ip": "192.0.2.10",
            "payload": {"event": "doorbell", "nested": {"state": "pressed"}},
        },
    )

    assert facts["webhook_key"] == "hook-key"
    assert facts["webhook_sender_ip"] == "192.0.2.10"
    assert "doorbell" in facts["message"]






def test_webhook_triggers_generate_high_entropy_keys_when_requested() -> None:
    triggers = normalize_triggers(
        [{"type": "webhook.received", "config": {"webhook_key": "weak-hook"}}],
        generate_webhook_keys=True,
    )

    config = triggers[0]["config"]
    assert is_high_entropy_webhook_key(config["webhook_key"])
    assert config["webhook_key_strength"] == "server_generated"


def test_high_impact_webhook_triggers_require_hmac_for_hardware_actions() -> None:
    triggers = normalize_triggers(
        [{"type": "webhook.received", "config": {"webhook_key": "weak-hook"}}],
        generate_webhook_keys=True,
    )
    actions = normalize_actions([{"type": "gate.open", "config": {"reason": "test"}}])

    automation_webhooks.harden_webhook_triggers_for_actions(triggers, actions)

    config = triggers[0]["config"]
    assert is_high_entropy_webhook_key(config["webhook_key"])
    assert config["require_hmac"] is True
    assert config["rate_limit_per_minute"] == automation_webhooks.WEBHOOK_RATE_LIMIT_PER_MINUTE


def test_webhook_hmac_and_source_policy_helpers() -> None:
    key = generate_automation_webhook_key()
    now = datetime(2026, 5, 31, 12, 0, tzinfo=UTC)
    timestamp = str(int(now.timestamp()))
    nonce = "nonce-1"
    raw_body = b'{"ok":true}'
    signature = hmac.new(
        key.encode(),
        b".".join([timestamp.encode(), nonce.encode(), raw_body]),
        hashlib.sha256,
    ).hexdigest()

    assert automation_webhooks.verify_webhook_hmac(
        key,
        raw_body,
        signature=f"sha256={signature}",
        timestamp=timestamp,
        nonce=nonce,
        window_seconds=300,
        now=now,
    )
    assert not automation_webhooks.verify_webhook_hmac(
        key,
        raw_body,
        signature=signature,
        timestamp=str(int((now - timedelta(minutes=10)).timestamp())),
        nonce=nonce,
        window_seconds=300,
        now=now,
    )
    assert automation_webhooks.webhook_source_allowed("192.0.2.10", ["192.0.2.0/24"])
    assert not automation_webhooks.webhook_source_allowed("198.51.100.10", ["192.0.2.0/24"])


class FakeNonceSession:
    def __init__(self, *, existing: bool = False, flush_error: bool = False) -> None:
        self.existing = existing
        self.flush_error = flush_error
        self.added: list[object] = []
        self.last_scalar_statement = ""

    async def execute(self, _statement):
        return None

    async def scalar(self, _statement):
        self.last_scalar_statement = str(_statement)
        return uuid.uuid4() if self.existing else None

    def add(self, row) -> None:
        self.added.append(row)

    async def flush(self) -> None:
        if self.flush_error:
            raise IntegrityError("insert", {}, Exception("duplicate"))

    async def rollback(self) -> None:
        return None


@pytest.mark.asyncio
async def test_webhook_nonce_recorder_rejects_replay() -> None:
    now = datetime(2026, 5, 31, 12, 0, tzinfo=UTC)
    session = FakeNonceSession()

    await automation_webhooks.remember_webhook_nonce(
        session,
        "hook-key",
        "192.0.2.10",
        nonce="nonce-a",
        signature_timestamp=str(int(now.timestamp())),
        window_seconds=300,
    )

    assert len(session.added) == 1
    nonce_row = session.added[0]
    assert nonce_row.nonce_hash == automation_webhooks.webhook_nonce_hash("nonce-a")
    assert nonce_row.expires_at == now + timedelta(seconds=300)
    assert "source_ip" not in session.last_scalar_statement

    with pytest.raises(automation_errors.AutomationError):
        await automation_webhooks.remember_webhook_nonce(
            FakeNonceSession(existing=True),
            "hook-key",
            "192.0.2.10",
            nonce="nonce-a",
            signature_timestamp=str(int(now.timestamp())),
            window_seconds=300,
        )


@pytest.mark.asyncio
async def test_webhook_nonce_recorder_rejects_concurrent_duplicate() -> None:
    now = datetime(2026, 5, 31, 12, 0, tzinfo=UTC)

    with pytest.raises(automation_errors.AutomationError):
        await automation_webhooks.remember_webhook_nonce(
            FakeNonceSession(flush_error=True),
            "hook-key",
            "192.0.2.10",
            nonce="nonce-a",
            signature_timestamp=str(int(now.timestamp())),
            window_seconds=300,
        )


@pytest.mark.asyncio
async def test_receive_automation_webhook_rejects_invalid_json() -> None:
    with pytest.raises(HTTPException) as exc:
        await automations_api.receive_automation_webhook(
            "hook-key",
            make_request("POST", "/api/v1/automations/webhooks/hook-key", body=b"{not-json"),
        )

    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_scheduler_reserves_before_wakeup_without_in_memory_execution_handoff(monkeypatch) -> None:
    service = AutomationService()
    calls = []
    async def reserve():
        calls.append("reserve_and_commit")
        return 1
    def wake():
        calls.append("wake")
    async def forbidden(*args, **kwargs):
        raise AssertionError("Scheduler must not hand execution through an in-memory run list")
    monkeypatch.setattr(service, "_reserve_due_rules", reserve)
    monkeypatch.setattr(service.dispatcher, "wake", wake)
    monkeypatch.setattr(service, "execute_rule", forbidden)
    await service._process_due_rules()
    assert calls == ["reserve_and_commit", "wake"]


@pytest.mark.asyncio
async def test_run_response_serializes_payload_before_session_closes(monkeypatch) -> None:
    run = AutomationRun(id=uuid.uuid4(), rule_id=None, trigger_key="time.every_x", status="skipped",
        started_at=datetime.now(tz=UTC), context={}, trigger_payload={}, condition_results=[], action_results=[])
    class Session:
        closed = False
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            self.closed = True
        async def get(self, model, identity):
            assert model is AutomationRun and identity == run.id
            return run
    session = Session()
    original = automations.serialize_run
    def serialize(row):
        assert not session.closed
        return original(row)
    monkeypatch.setattr(automations, "AsyncSessionLocal", lambda: session)
    monkeypatch.setattr(automations, "serialize_run", serialize)
    result = await AutomationService().run_response(run.id)
    assert result["run"]["id"] == str(run.id) and result["status"] == "skipped"
    assert session.closed


def _policy_admin():
    return automations.User(id=uuid.uuid4(), username="synthetic-policy-admin",
                            full_name="Synthetic Policy Admin", password_hash="not-used",
                            role=UserRole.ADMIN, is_active=True)


def _policy_rule(trigger="vehicle.known_plate", action="gate.open", *, active=True):
    return AutomationRule(
        id=uuid.uuid4(), name="Synthetic policy workflow", is_active=active,
        triggers=normalize_triggers([{"type": trigger, "config": {}}]), trigger_keys=[trigger],
        actions=normalize_actions([{"id": "action-1", "type": action, "config": {}}]),
        conditions=[], run_count=0,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("action", ["gate.open", "garage_door.open", "garage_door.close"])
async def test_unknown_hardware_rule_is_rejected_before_add_or_audit(monkeypatch, action):
    audit = AsyncMock()
    monkeypatch.setattr(automations, "write_audit_log", audit)
    session = SimpleNamespace(add=lambda row: pytest.fail("Rejected rule was added"))
    with pytest.raises(automation_errors.AutomationError, match="Unknown plates"):
        await AutomationService().create_rule(
            session, name="Synthetic unsafe rule", created_by=_policy_admin(),
            triggers=[{"type": "vehicle.unknown_plate", "config": {}}], conditions=[],
            actions=[{"id": "hardware", "type": action, "config": {}}],
        )
    audit.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("change", ["trigger", "action", "reenable", "rename"])
async def test_unknown_hardware_update_validates_merged_rule_before_mutation(monkeypatch, change):
    rule = _policy_rule()
    if change == "trigger":
        changes = {"triggers": [{"type": "vehicle.unknown_plate", "config": {}}]}
    elif change == "action":
        rule = _policy_rule("vehicle.unknown_plate", "notification.enable")
        changes = {"actions": [{"id": "hardware", "type": "gate.open", "config": {}}]}
    else:
        rule = _policy_rule("vehicle.unknown_plate", active=change != "reenable")
        changes = {"is_active": True} if change == "reenable" else {"name": "Changed name"}
    before = automations.serialize_rule(rule)
    audit = AsyncMock()
    session = SimpleNamespace(refresh=AsyncMock())
    monkeypatch.setattr(automations, "write_audit_log", audit)
    with pytest.raises(automation_errors.AutomationError, match="Unknown plates"):
        await AutomationService().update_rule(session, rule, actor=_policy_admin(), **changes)
    assert automations.serialize_rule(rule) == before
    session.refresh.assert_awaited_once_with(rule, with_for_update=True)
    audit.assert_not_awaited()


@pytest.mark.asyncio
async def test_existing_unsafe_rule_can_be_disabled_without_deleting_its_configuration(monkeypatch):
    rule = _policy_rule("vehicle.unknown_plate")
    triggers, actions = rule.triggers, rule.actions
    audit = AsyncMock()
    monkeypatch.setattr(automations, "write_audit_log", audit)
    session = SimpleNamespace(refresh=AsyncMock(), flush=AsyncMock())
    result = await AutomationService().update_rule(session, rule, actor=_policy_admin(), is_active=False)
    assert result is rule and not rule.is_active
    assert rule.triggers == triggers and rule.actions == actions
    assert audit.await_args.kwargs["action"] == "automation_rule.update"


@pytest.mark.asyncio
async def test_context_captures_original_recognition_evidence_before_rendering():
    payload = {"decision": "denied", "vehicle_id": None, "event_id": "synthetic-event"}
    context = await AutomationService().context_for_trigger("vehicle.known_plate", payload)
    payload.update(decision="granted", vehicle_id="synthetic-vehicle", confirmed=True, user_role="admin")
    assert public_automation_context(context)["provenance"] == {
        "trigger_key": "vehicle.known_plate", "decision": "denied", "vehicle_id": None,
        "event_id": "synthetic-event", "historical": False,
    }
    result = await AutomationService()._execute_action(
        SimpleNamespace(), {"id": "gate", "type": "gate.open"}, context, rule=_policy_rule()
    )
    assert result["status"] == "skipped" and not result["command_sent"]
    assert result["reason_code"] == "unknown_plate_hardware_forbidden"


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["standard", "admin"])
async def test_phrase_observation_cannot_claim_hardware_confirmation_in_payload(role):
    context = await AutomationService().context_for_trigger("ai.phrase_received", {
        "phrase": "Synthetic open", "user_id": "synthetic-user", "user_role": role,
        "confirmed": True, "confirmation_id": "untrusted-confirmation", "actor": "Automation Engine",
    })
    result = await AutomationService()._execute_action(
        SimpleNamespace(), {"id": "gate", "type": "gate.open"}, context, rule=_policy_rule("ai.phrase_received")
    )
    assert result["status"] == "skipped" and not result["command_sent"]
    assert result["requires_confirmation"] is True
    assert result["reason_code"] == "requester_confirmation_required"


def test_hardware_admission_covers_every_registered_gate_or_garage_action():
    from app.services.automation_policy import HARDWARE_ACTION_TYPES

    registered = {action["type"] for group in ACTION_CATALOG for action in group["actions"]
                  if action["type"].startswith(("gate.", "garage_door."))}
    assert registered == HARDWARE_ACTION_TYPES




def test_automation_definition_and_intake_do_not_import_execution_facades():
    import ast
    from pathlib import Path
    base = Path(__file__).resolve().parents[1] / "app/services"
    definition = ast.parse((base / "workflows/automation_definition.py").read_text())
    allowed = {"app.services.workflows.action_definitions", "app.services.automation_policy", "app.services.type_helpers",
               "app.services.workflows.catalog", "app.services.workflows.context"}
    assert {node.module for node in ast.walk(definition) if isinstance(node, ast.ImportFrom)
            and (node.module or "").startswith("app.")} <= allowed
    intake = ast.parse((base / "automation_intake.py").read_text())
    forbidden = {"app.services.automations", "app.services.automation_integration_actions", "app.services.access_devices",
                 "app.services.notifications"}
    assert not {node.module for node in ast.walk(intake) if isinstance(node, ast.ImportFrom)} & forbidden
    assert not {node.func.attr for node in ast.walk(intake) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)} & {"commit", "publish", "wake", "command_device", "execute_open"}


async def test_automation_lifecycle_has_no_realtime_bridge_subscription(monkeypatch):
    import asyncio
    service = AutomationService()
    started = asyncio.Event()
    async def scheduler():
        started.set()
        await asyncio.Event().wait()
    subscribe, unsubscribe = Mock(), Mock()
    monkeypatch.setattr(automations.event_bus, "subscribe", subscribe)
    monkeypatch.setattr(automations.event_bus, "unsubscribe", unsubscribe)
    monkeypatch.setattr(service, "_run_scheduler", scheduler)
    service.dispatcher = SimpleNamespace(start=Mock(), stop=AsyncMock())
    await service.start()
    await asyncio.wait_for(started.wait(), 1)
    await service.stop()
    subscribe.assert_not_called()
    unsubscribe.assert_not_called()
    service.dispatcher.start.assert_called_once()
    service.dispatcher.stop.assert_awaited_once()


@pytest.mark.asyncio
async def test_prepared_external_action_keeps_canonical_targets_and_deadline_without_plan_metadata(monkeypatch):
    from app.services.workflows.execution_contracts import AutomationExecution
    service = AutomationService()
    token, run_id, operation_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    action = {"id": "synthetic-open", "type": "gate.open", "config": {}, "reason_template": "Synthetic"}
    target = {"provider": "synthetic", "nested": {"entity": "gate"}}
    targets = [target, {"provider": "secondary"}]
    deadline = datetime.now(UTC) + timedelta(seconds=20)
    item = {"action": action, "state": "pending", "index": 0,
            "operation_id": str(operation_id), "idempotency_key": "synthetic-plan"}
    current = SimpleNamespace(action_plan=[item], context={})
    rule = SimpleNamespace(id=uuid.uuid4())
    class Session:
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        scalar = AsyncMock(return_value=rule)
        flush = AsyncMock()
        commit = AsyncMock()
    session = Session()
    monkeypatch.setattr(automations, "AsyncSessionLocal", lambda: session)
    monkeypatch.setattr(automations, "restored_automation_context", lambda snapshot: AutomationContext(trigger_key="time.every_x", subject="Synthetic", trigger_payload={}))
    service.run_store.owned = AsyncMock(return_value=(current, datetime.now(UTC)))
    attempted = {**item, "state": "attempting", "attempted_at": "synthetic-history",
                 "result": {"status": "unrelated"}, "target_plan": target, "target_plans": targets}
    service.run_store.begin_action = AsyncMock(return_value=attempted)
    async def preflight(*args, deadlines, **kwargs):
        deadlines.update(expires_at=deadline, automatic_entry_policy=True)
    monkeypatch.setattr(service, "_preflight", preflight)
    prepared = await service.prepare_action_dispatch(SimpleNamespace(id=run_id, rule_id=rule.id), token, 0)
    assert prepared is not None
    assert set(prepared.execution) == set(AutomationExecution.__annotations__)
    assert prepared.execution["target_plan"] is target
    assert prepared.execution["target_plans"] is targets
    assert prepared.execution["expires_at"] is deadline
    assert prepared.execution["automatic_entry_policy"] is True
    assert prepared.execution["run_id"] == str(run_id)
    assert prepared.execution["claim_token"] == str(token)
    assert prepared.execution["operation_id"] == str(operation_id)
    assert prepared.execution["idempotency_key"] == "synthetic-plan"
    assert attempted["state"] == "attempting" and "attempted_at" in attempted
    session.commit.assert_awaited_once()
