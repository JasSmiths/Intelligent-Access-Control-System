import base64
import json
import uuid
from datetime import UTC, datetime, timedelta
from contextlib import asynccontextmanager
from io import BytesIO
from pathlib import Path
from time import monotonic
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import httpx
import pytest
from fastapi import FastAPI
from PIL import Image

from app.services import report_exports as exports_service
from app.services import report_renderer as renderer_service
from app.services.report_contracts import ReportAuthority, ReportDownload, ReportWork
from app.api.dependencies import current_user
from app.api.v1 import reports as reports_api
from app.db.session import get_db_session
from app.models import AccessEvent, ReportExport, User, VisitorPass
from app.models.enums import (
    AccessDecision,
    AccessDirection,
    TimingClassification,
    UserRole,
    VisitorPassStatus,
    VisitorPassType,
)
from app.services import auth as auth_service
from app.services import reports as reports_service
from app.services import report_durations as duration_service
from app.services import snapshots as snapshots_service
from app.services import report_images as images_service
from app.services.report_reads import ReportEvent, ReportPerson
from app.services.report_contracts import ReportLimitError


def make_user() -> User:
    now = datetime(2026, 5, 5, 12, 0, tzinfo=UTC)
    return User(
        id=uuid.uuid4(),
        username="admin",
        first_name="Admin",
        last_name="User",
        full_name="Admin User",
        email="admin@example.com",
        password_hash="not-used",
        role=UserRole.ADMIN,
        is_active=True,
        created_at=now,
        updated_at=now,
    )


def make_event(
    *,
    occurred_at: datetime,
    direction: AccessDirection,
    decision: AccessDecision = AccessDecision.GRANTED,
    registration_number: str = "AGS7X",
) -> AccessEvent:
    event = AccessEvent(
        id=uuid.uuid4(),
        registration_number=registration_number,
        direction=direction,
        decision=decision,
        confidence=0.94,
        source="ubiquiti",
        occurred_at=occurred_at,
        timing_classification=TimingClassification.UNKNOWN,
        raw_payload={},
    )
    event.anomalies = []
    return event


def test_report_duration_formatting() -> None:
    start = datetime(2026, 5, 1, 8, 0, tzinfo=UTC)

    short = duration_service.format_duration_info(
        start,
        start + timedelta(hours=6, minutes=12),
        "Short duration",
        timezone=ZoneInfo("UTC"),
    )
    medium = duration_service.format_duration_info(
        start,
        start + timedelta(days=12, hours=3, minutes=8),
        "Medium duration",
        timezone=ZoneInfo("UTC"),
    )
    long = duration_service.format_duration_info(
        start,
        start + timedelta(days=78),
        "Long duration",
        timezone=reports_service._timezone("UTC"),
    )

    assert short["label"] == "6hrs 12m"
    assert medium["label"] == "12 Days, 3hrs 8m"
    assert long["label"] == "01/05/2026 - 08:00"
    assert long["tooltip"] == "2 Months, 18 Days"
    london = duration_service.format_duration_info(
        start, start + timedelta(days=78), "Long duration", timezone=ZoneInfo("Europe/London"),
    )
    assert london["label"] == "01/05/2026 - 09:00"
    assert london["tooltip"] == long["tooltip"]


def test_report_duration_lookup_handles_arrivals_and_departures() -> None:
    first_arrival = make_event(
        occurred_at=datetime(2026, 5, 1, 8, 0, tzinfo=UTC),
        direction=AccessDirection.ENTRY,
    )
    departure = make_event(
        occurred_at=datetime(2026, 5, 1, 14, 12, tzinfo=UTC),
        direction=AccessDirection.EXIT,
    )
    next_arrival = make_event(
        occurred_at=datetime(2026, 5, 2, 9, 0, tzinfo=UTC),
        direction=AccessDirection.ENTRY,
    )

    durations = duration_service.build_duration_lookup(
        [first_arrival, departure, next_arrival],
        [first_arrival, departure, next_arrival],
        timezone=ZoneInfo("UTC"),
    )

    assert durations[str(first_arrival.id)]["label"] == "New Arrival"
    assert durations[str(departure.id)]["label"] == "6hrs 12m"
    assert durations[str(next_arrival.id)]["label"] == "18hrs 48m"


async def test_report_id_generation_skips_existing(monkeypatch) -> None:
    values = iter([0, 42])

    class FakeSession:
        def __init__(self) -> None:
            self.calls = 0

        async def scalar(self, _statement):
            self.calls += 1
            return uuid.uuid4() if self.calls == 1 else None

    monkeypatch.setattr(reports_service.secrets, "randbelow", lambda _limit: next(values))

    report_id = await reports_service.generate_report_number(FakeSession())

    assert report_id == "100042"


def test_snapshot_toggle_controls_serialized_event_media(monkeypatch) -> None:
    event = make_event(
        occurred_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
        direction=AccessDirection.ENTRY,
    )
    event.snapshot_path = "snapshots/access-events/example.jpg"
    event.snapshot_content_type = "image/jpeg"
    monkeypatch.setattr(
        reports_service,
        "access_event_snapshot_payload",
        lambda item, **_kwargs: {
            "snapshot_url": f"/api/v1/events/{item.id}/snapshot",
            "snapshot_captured_at": None,
            "snapshot_bytes": 100,
            "snapshot_width": 640,
            "snapshot_height": 360,
            "snapshot_camera": "Gate",
        },
    )

    without_snapshot = reports_service.serialize_report_event(
        compact_event(event),
        include_snapshots=False,
        duration={"label": "New Arrival"},
        timezone=reports_service._timezone("Europe/London"),
    )
    with_snapshot = reports_service.serialize_report_event(
        compact_event(event),
        include_snapshots=True,
        duration={"label": "New Arrival"},
        timezone=reports_service._timezone("Europe/London"),
    )

    assert without_snapshot["snapshot_url"] is None
    assert without_snapshot["_snapshot_path"] is None
    assert with_snapshot["snapshot_url"] == f"/api/v1/events/{event.id}/snapshot"
    assert with_snapshot["_snapshot_path"] == "snapshots/access-events/example.jpg"


def test_pdf_safe_profile_image_keeps_browser_supported_data_url() -> None:
    source = BytesIO()
    Image.new("RGB", (12, 9), "#8ab4f8").save(source, format="JPEG")
    data_url = "data:image/jpeg;base64," + base64.b64encode(source.getvalue()).decode("ascii")
    report = renderer_service.report_for_pdf({"person": {"profile_photo_data_url": data_url}, "events": []}, ReportWork(monotonic() + 120))
    assert report["person"]["pdf_profile_photo_data_url"] == data_url


def test_pdf_safe_profile_image_resizes_converted_images() -> None:
    source = BytesIO()
    Image.new("RGB", (1200, 900), "#8ab4f8").save(source, format="TIFF")
    data_url = f"data:image/tiff;base64,{base64.b64encode(source.getvalue()).decode('ascii')}"
    report = renderer_service.report_for_pdf({"person": {"profile_photo_data_url": data_url}, "events": []}, ReportWork(monotonic() + 120))
    converted = report["person"]["pdf_profile_photo_data_url"]
    assert converted.startswith("data:image/jpeg;base64,")
    with Image.open(BytesIO(base64.b64decode(converted.split(",", 1)[1]))) as image:
        assert max(image.size) == images_service.PDF_SAFE_PROFILE_IMAGE_MAX_EDGE_PX


def test_pdf_report_uses_verified_profile_photo_without_mutating_snapshot() -> None:
    source = BytesIO()
    Image.new("RGB", (12, 9), "#8ab4f8").save(source, format="PNG")
    data_url = "data:image/png;base64," + base64.b64encode(source.getvalue()).decode("ascii")
    snapshot = {"person": {"profile_photo_data_url": data_url}, "brand": {}, "events": []}
    report = renderer_service.report_for_pdf(snapshot, ReportWork(monotonic() + 120))
    assert report["person"]["pdf_profile_photo_data_url"] == data_url
    assert "pdf_profile_photo_data_url" not in snapshot["person"]
    assert report["brand"]["site"] == "Crest House"


def test_public_report_snapshot_strips_embedded_media() -> None:
    public = reports_service.public_report_snapshot(
        {
            "person": {
                "profile_photo_data_url": "data:image/jpeg;base64,person",
                "profile_photo_url": "/api/v1/people/person-id/photo",
                "pdf_profile_photo_data_url": "data:image/jpeg;base64,pdf",
                "vehicles": [
                    {
                        "vehicle_photo_data_url": "data:image/jpeg;base64,vehicle",
                        "vehicle_photo_url": "/api/v1/vehicles/vehicle-id/photo",
                    }
                ],
            },
            "events": [
                {
                    "_snapshot_path": "snapshots/access-events/example.jpg",
                    "_snapshot_content_type": "image/jpeg",
                    "pdf_snapshot_data_url": "data:image/jpeg;base64,snapshot",
                }
            ],
        }
    )

    assert "profile_photo_data_url" not in public["person"]
    assert public["person"]["profile_photo_url"] == "/api/v1/people/person-id/photo"
    assert "vehicle_photo_data_url" not in public["person"]["vehicles"][0]
    assert public["person"]["vehicles"][0]["vehicle_photo_url"] == "/api/v1/vehicles/vehicle-id/photo"
    assert "_snapshot_path" not in public["events"][0]


def test_visitor_pass_serializes_as_report_subject() -> None:
    visitor_pass = VisitorPass(
        id=uuid.uuid4(),
        visitor_name="Taylor Visitor",
        pass_type=VisitorPassType.DURATION,
        visitor_phone=None,
        expected_time=datetime(2026, 5, 5, 10, 0, tzinfo=UTC),
        window_minutes=60,
        status=VisitorPassStatus.ACTIVE,
        number_plate="VIS123",
        vehicle_make="Ford",
        vehicle_colour="White",
    )

    subject = reports_service.serialize_report_visitor_pass(visitor_pass)

    assert subject["id"] == str(visitor_pass.id)
    assert subject["display_name"] == "Taylor Visitor"
    assert subject["group"] == "Visitor Pass"
    assert subject["pronouns"] is None
    assert subject["vehicles"][0]["registration_number"] == "VIS123"
    assert subject["vehicles"][0]["title"] == "Ford"
    assert subject["vehicles"][0]["color"] == "White"


def app_for_reports(user: User) -> FastAPI:
    app = FastAPI()
    app.include_router(reports_api.router, prefix="/api/v1/reports")

    async def override_current_user() -> User:
        return user

    async def override_db_session():
        yield SimpleNamespace()

    async def override_report_authority():
        return ReportAuthority(user.id, "synthetic-only")

    app.dependency_overrides[reports_api.report_authority] = override_report_authority
    app.dependency_overrides[current_user] = override_current_user
    app.dependency_overrides[get_db_session] = override_db_session
    return app


async def test_report_export_endpoint_returns_download_payload(monkeypatch) -> None:
    user = make_user()
    row = ReportExport(
        id=uuid.uuid4(),
        report_number="123456",
        report_type=reports_service.REPORT_TYPE_PERSON_MOVEMENTS,
        person_id=uuid.uuid4(),
        period_start=datetime(2026, 5, 1, 8, 0, tzinfo=UTC),
        period_end=datetime(2026, 5, 5, 8, 0, tzinfo=UTC),
        options={"include_snapshots": True},
        snapshot={"report_id": "123456", "events": [], "person": {"display_name": "Ash Smith"}},
        pdf_path="reports/person-movements-123456.pdf",
        pdf_bytes=321,
        created_by_user_id=user.id,
        created_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
        updated_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
    )

    async def fake_create(*_args, **_kwargs):
        return reports_service.report_export_payload(row)

    monkeypatch.setattr(reports_api.report_exports, "export", fake_create)
    app = app_for_reports(user)
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/reports/person-movements/export",
            json={
                "person_id": str(uuid.uuid4()),
                "period_start": "2026-05-01T08:00:00Z",
                "period_end": "2026-05-05T08:00:00Z",
                "include_snapshots": True,
            },
        )

    assert response.status_code == 200
    payload = response.json()
    assert payload["report_id"] == "123456"
    assert payload["download_url"] == "/api/v1/reports/123456/pdf"
    assert payload["report"]["report_id"] == "123456"


async def test_report_export_endpoint_accepts_visitor_pass_subject(monkeypatch) -> None:
    user = make_user()
    visitor_pass_id = uuid.uuid4()
    captured_kwargs = {}
    row = ReportExport(
        id=uuid.uuid4(),
        report_number="456789",
        report_type=reports_service.REPORT_TYPE_PERSON_MOVEMENTS,
        person_id=None,
        period_start=datetime(2026, 5, 1, 8, 0, tzinfo=UTC),
        period_end=datetime(2026, 5, 5, 8, 0, tzinfo=UTC),
        options={"include_snapshots": False},
        snapshot={
            "report_id": "456789",
            "subject_type": "visitor_pass",
            "events": [],
            "person": {"id": str(visitor_pass_id), "display_name": "Taylor Visitor"},
        },
        pdf_path="reports/person-movements-456789.pdf",
        pdf_bytes=456,
        created_by_user_id=user.id,
        created_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
        updated_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
    )

    async def fake_create(request, authority, **_kwargs):
        captured_kwargs.update(vars(request))
        assert authority.user_id == user.id
        return reports_service.report_export_payload(row)

    monkeypatch.setattr(reports_api.report_exports, "export", fake_create)
    app = app_for_reports(user)
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/reports/person-movements/export",
            json={
                "visitor_pass_id": str(visitor_pass_id),
                "period_start": "2026-05-01T08:00:00Z",
                "period_end": "2026-05-05T08:00:00Z",
                "include_snapshots": False,
            },
        )

    assert response.status_code == 200
    assert captured_kwargs["person_id"] is None
    assert captured_kwargs["visitor_pass_id"] == visitor_pass_id
    assert response.json()["report"]["subject_type"] == "visitor_pass"


async def test_report_lookup_and_pdf_download(monkeypatch, tmp_path) -> None:
    user = make_user()
    pdf_path = tmp_path / "report.pdf"
    pdf_path.write_bytes(b"%PDF-1.4\n%test\n")
    row = ReportExport(
        id=uuid.uuid4(),
        report_number="654321",
        report_type=reports_service.REPORT_TYPE_PERSON_MOVEMENTS,
        person_id=uuid.uuid4(),
        period_start=datetime(2026, 5, 1, 8, 0, tzinfo=UTC),
        period_end=datetime(2026, 5, 5, 8, 0, tzinfo=UTC),
        options={},
        snapshot={"report_id": "654321", "events": [{"id": "event", "_snapshot_path": "hidden"}]},
        pdf_path="reports/person-movements-654321.pdf",
        pdf_bytes=pdf_path.stat().st_size,
        created_by_user_id=user.id,
        created_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
        updated_at=datetime(2026, 5, 5, 12, 0, tzinfo=UTC),
    )

    async def fake_load(_session, report_id, *, actor):
        assert actor.id == user.id
        return row if report_id == "654321" else None

    monkeypatch.setattr(reports_api, "load_report_export", fake_load)
    async def fake_download(_session, report_id, *, actor):
        value = await fake_load(_session, report_id, actor=actor)
        return ReportDownload(value.report_number, value.pdf_path) if value else None

    monkeypatch.setattr(reports_api, "load_report_download", fake_download)
    monkeypatch.setattr(reports_api, "report_pdf_path", lambda _row: pdf_path)
    app = app_for_reports(user)
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        lookup = await client.get("/api/v1/reports/654321")
        download = await client.get("/api/v1/reports/654321/pdf")

    assert lookup.status_code == 200
    assert lookup.json()["report"]["events"][0].get("_snapshot_path") is None
    assert download.status_code == 200
    assert download.headers["content-type"] == "application/pdf"
    assert "Crest-House-Access-Report-654321.pdf" in download.headers["content-disposition"]
    assert download.content.startswith(b"%PDF")




PREVIEW_CONTRACT = json.loads(
    (Path(__file__).parent / "contracts/fixtures/reports/preview_contract.json").read_text()
)


@pytest.mark.parametrize(("local", "expected"), [
    ("2026-07-14T09:00:00", "2026-07-14T08:00:00+00:00"),
    ("2026-01-14T09:00:00", "2026-01-14T09:00:00+00:00"),
    ("2026-10-25T01:30:00+01:00", "2026-10-25T00:30:00+00:00"),
    ("2026-10-25T01:30:00+00:00", "2026-10-25T01:30:00+00:00"),
])
def test_report_boundary_uses_site_zone_and_preserves_aware_instants(local, expected):
    resolved, choice = reports_service.resolve_report_boundary(
        datetime.fromisoformat(local), timezone=reports_service._timezone("Europe/London"), field="period_start",
    )
    assert resolved.isoformat() == expected
    assert choice is None


@pytest.mark.parametrize("case", PREVIEW_CONTRACT["fold_requests"])
def test_report_boundary_requires_explicit_occurrence(case):
    local = datetime.fromisoformat(case["period_start"])
    zone = reports_service._timezone("Europe/London")
    resolved, choice = reports_service.resolve_report_boundary(local, timezone=zone, field="period_start")
    assert resolved is None
    assert choice == PREVIEW_CONTRACT["ambiguous"]["time_choices"][0]
    resolved, choice = reports_service.resolve_report_boundary(
        local, timezone=zone, field="period_start", fold=case["period_start_fold"],
    )
    assert resolved.isoformat() == case["resolved_start"]
    assert choice is None


def test_report_boundary_rejects_nonexistent_time_instead_of_normalizing_it():
    case = PREVIEW_CONTRACT["gap"]
    with pytest.raises(reports_service.ReportExportError, match="Start time does not exist") as exc:
        reports_service.resolve_report_boundary(
            datetime.fromisoformat(case["period_start"]),
            timezone=reports_service._timezone("Europe/London"), field="period_start",
        )
    assert str(exc.value) == case["detail"]


def report_person():
    return ReportPerson(
        id=uuid.UUID(PREVIEW_CONTRACT["ready"]["report"]["person"]["id"]),
        first_name="Synthetic", last_name="Resident", display_name="Synthetic Resident",
        pronouns=None, profile_photo_data_url=None, group_name=None, group_category=None,
        vehicles=[], presence=None, updated_at=None,
    )


def compact_event(event):
    visitor = (event.raw_payload or {}).get("visitor_pass", {})
    return ReportEvent(
        event.id, event.registration_number, event.direction, event.decision,
        event.confidence, event.source, event.occurred_at, event.timing_classification,
        event.snapshot_path, event.snapshot_content_type, event.snapshot_bytes,
        event.snapshot_width, event.snapshot_height, event.snapshot_captured_at,
        event.snapshot_camera, visitor.get("id"), visitor.get("visitor_name"), visitor.get("mode"),
        len(event.anomalies),
    )


class ReportRows:
    def __init__(self, rows):
        self.rows = rows

    def all(self):
        return self.rows

    def first(self):
        return self.rows[0] if self.rows else None

    def __iter__(self):
        return iter(self.rows)


class ReportReadSession:
    """Composed snapshot fixture; genuine SQL behavior is covered by PG fixtures."""
    def __init__(self, event_batches=()):
        batches = list(event_batches)
        self.events, self.history, self.timeline = (batches + [[], [], []])[:3]
        self.queries = []

    async def scalar(self, statement):
        self.queries.append(statement)
        return report_person()

    async def execute(self, statement):
        self.queries.append(statement)
        sql = str(statement)
        params = statement.compile().params
        columns = list(statement.selected_columns)
        if "FROM people" in sql:
            person = report_person()
            return ReportRows([(person.id, person.first_name, person.last_name, person.display_name,
                               person.pronouns, None, 0, None, None, None)])
        if "FROM vehicles" in sql and "FROM access_events" not in sql:
            return ReportRows([])
        if "FROM anomalies" in sql:
            return ReportRows([])
        if len(columns) == 18:
            events = self.events
            if " != " in sql:
                events = [event for event in events if event.decision != AccessDecision.DENIED]
            events = sorted(events, key=lambda event: (event.occurred_at, event.id))
            return ReportRows([tuple(vars(compact_event(event)).values())[:18]
                               for event in events[:statement._limit_clause.value]])
        if "occurred_at < :" not in sql:
            return ReportRows([(event.id, event.registration_number, event.direction, event.decision,
                                event.occurred_at) for event in self.timeline[:statement._limit_clause.value]])
        boundary = params["occurred_at_1"]
        history = [event for event in self.history if event.occurred_at < boundary]
        if "direction_2" in params:
            history = [event for event in history if event.direction == params["direction_2"]]
            history = sorted(history, key=lambda event: event.occurred_at, reverse=True)[:1]
        return ReportRows([(event.id, event.registration_number, event.direction, event.decision,
                            event.occurred_at) for event in history])

    async def get(self, _model, _identity):
        return None


def forbid_report_effects(monkeypatch):
    def forbidden(*_args, **_kwargs):
        raise AssertionError("Preview attempted a write, media restoration or export effect")

    for name in ("generate_report_number", "render_person_movement_report_pdf", "write_audit_log", "_resolve_report_path"):
        monkeypatch.setattr(exports_service, name, forbidden)
    monkeypatch.setattr(images_service, "get_snapshot_manager", forbidden)
    monkeypatch.setattr(snapshots_service, "get_snapshot_manager", forbidden)


async def london_report_config():
    return SimpleNamespace(site_timezone="Europe/London")


@asynccontextmanager
async def synthetic_report_transaction(_session):
    # Real isolation/config transaction behavior is exercised by PG fixtures.
    yield await london_report_config()


@pytest.fixture(autouse=True)
def report_snapshot_source(monkeypatch):
    monkeypatch.setattr(reports_service, "report_read_transaction", synthetic_report_transaction)


async def test_preview_contract_is_built_without_export_or_persistence(monkeypatch):
    class FixedClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime(2026, 7, 14, 9, tzinfo=UTC)

    monkeypatch.setattr(reports_service, "datetime", FixedClock)
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    session = ReportReadSession([[], [], []])
    preview = await reports_service.preview_person_movement_report(
        session, person_id=report_person().id,
        period_start=datetime(2026, 7, 14, 9), period_end=datetime(2026, 7, 14, 10),  # noqa: DTZ001 -- exercise civil site-time input
        include_denied=False, include_snapshots=True, include_confidence=True,
    )
    # Brand is an existing site presentation constant, outside this synthetic DTO fixture.
    preview["report"].pop("brand")
    assert preview == PREVIEW_CONTRACT["ready"]
    assert len(session.queries) == 7


async def test_preview_complete_history_duration_and_media_are_shared_with_export_builder(monkeypatch):
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    start = datetime(2026, 7, 14, 8, tzinfo=UTC)
    prior = make_event(occurred_at=start - timedelta(hours=6), direction=AccessDirection.ENTRY)
    departures = [make_event(occurred_at=start + timedelta(minutes=index), direction=AccessDirection.EXIT) for index in range(251)]
    departures[0].snapshot_path = "snapshots/access-events/synthetic.jpg"
    departures[0].snapshot_content_type = "image/jpeg"
    session = ReportReadSession([departures, [prior, *departures], departures])
    preview = await reports_service.preview_person_movement_report(
        session, person_id=report_person().id, period_start=start, period_end=start + timedelta(hours=5),
        include_denied=False, include_snapshots=True, include_confidence=True,
    )
    report = preview["report"]
    assert preview["complete"] is True
    assert len(report["events"]) == 251
    assert report["summary"]["total"] == 251
    first_departure = report["events"][-1]
    assert first_departure["duration"] == {"label": "6hrs 0m"}
    assert first_departure["snapshot_url"] == f"/api/v1/events/{departures[0].id}/snapshot"
    assert "_snapshot_path" not in first_departure
    selected_query = next(query for query in session.queries if len(query.selected_columns) == 18)
    assert selected_query._limit_clause.value == 10001
    assert session.queries[-1]._limit_clause.value == 10000 - 251 * 2 + 1
    # Export invokes this same snapshot builder; media availability is its only read-policy difference.
    exported = reports_service.public_report_snapshot(await reports_service.build_movement_report_snapshot(
        ReportReadSession([departures, [prior, *departures], departures]),
        person_id=report_person().id, visitor_pass_id=None, report_number="123456",
        period_start=start, period_end=start + timedelta(hours=5),
        options=report["options"], timezone=reports_service._timezone("Europe/London"),
        verify_snapshot_availability=False,
    ))
    for key in ("events", "period", "summary", "timeline", "person", "presence", "options"):
        assert exported[key] == report[key]
    assert exported["report_id"] == "123456"


async def test_preview_visitor_keeps_existing_attribution_filter_and_options(monkeypatch):
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    arrival = make_event(occurred_at=datetime(2026, 7, 14, 8, tzinfo=UTC), direction=AccessDirection.ENTRY)
    denied = make_event(occurred_at=datetime(2026, 7, 14, 9, tzinfo=UTC), direction=AccessDirection.ENTRY, decision=AccessDecision.DENIED)
    visitor = VisitorPass(
        id=uuid.uuid4(), visitor_name="Synthetic Visitor", pass_type=VisitorPassType.DURATION,
        number_plate="SYNTH01", arrival_event_id=arrival.id, departure_event_id=None,
    )
    class VisitorReadSession(ReportReadSession):
        async def get(self, model, identity):
            assert model is VisitorPass and identity == visitor.id
            return visitor

    session = VisitorReadSession([[arrival, denied], [arrival], [arrival]])
    preview = await reports_service.preview_person_movement_report(
        session, visitor_pass_id=visitor.id,
        period_start=datetime(2026, 7, 14, 8, tzinfo=UTC), period_end=datetime(2026, 7, 14, 10, tzinfo=UTC),
        include_denied=False, include_snapshots=False, include_confidence=False,
    )
    assert preview["report"]["subject_type"] == "visitor_pass"
    assert preview["report"]["person"]["display_name"] == "Synthetic Visitor"
    assert len(preview["report"]["events"]) == 1
    assert preview["report"]["events"][0]["snapshot_url"] is None
    params = session.queries[0].compile().params.values()
    assert {"visitor_pass": {"id": str(visitor.id)}} in params
    assert "SYNTH01" in params
    assert [arrival.id] in params


async def test_preview_api_matches_choice_and_gap_contracts_and_validates_fold(monkeypatch):
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    app = app_for_reports(make_user())
    body = {"person_id": str(report_person().id), "period_start": "2026-10-25T01:30:00", "period_end": "2026-10-25T03:00:00"}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        ambiguous = await client.post("/api/v1/reports/person-movements/preview", json=body)
        invalid = await client.post("/api/v1/reports/person-movements/preview", json={**body, "period_start_fold": 2})
        gap = await client.post("/api/v1/reports/person-movements/preview", json={**body, "period_start": PREVIEW_CONTRACT["gap"]["period_start"]})
        backwards = await client.post("/api/v1/reports/person-movements/preview", json={**body, "period_start": "2026-10-25T04:00:00"})
    assert ambiguous.status_code == 200
    assert ambiguous.json() == PREVIEW_CONTRACT["ambiguous"]
    assert invalid.status_code == 422
    assert gap.status_code == PREVIEW_CONTRACT["gap"]["status_code"]
    assert gap.json() == {"detail": PREVIEW_CONTRACT["gap"]["detail"]}
    assert backwards.status_code == 400
    assert backwards.json() == {"detail": "Report end time must be after the start time."}


async def test_preview_api_retains_authentication_and_passes_aware_bounds(monkeypatch):
    app = app_for_reports(make_user())
    async def synthetic_auth_config():
        return SimpleNamespace(auth_cookie_name="synthetic_iacs_session")
    # Exercise real credential absence/denial without loading runtime settings from a database.
    monkeypatch.setattr(auth_service, "get_authentication_config", synthetic_auth_config)
    captured = {}
    async def preview(_session, **kwargs):
        captured.update(kwargs)
        return PREVIEW_CONTRACT["ready"]
    monkeypatch.setattr(reports_api, "preview_person_movement_report", preview)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post("/api/v1/reports/person-movements/preview", json={
            "person_id": str(report_person().id), "period_start": "2026-10-25T01:30:00+01:00",
            "period_end": "2026-10-25T01:30:00+00:00",
        })
        app.dependency_overrides.pop(current_user)
        anonymous = await client.post("/api/v1/reports/person-movements/preview", json={})
    assert response.json() == PREVIEW_CONTRACT["ready"]
    assert captured["period_start"].utcoffset() == timedelta(hours=1)
    assert captured["period_end"].utcoffset() == timedelta(0)
    assert anonymous.status_code == 401


def test_frontend_report_fixture_is_generated_from_canonical_contract():
    frontend_fixture = Path(__file__).parents[2] / "frontend/src/api/fixtures/reportPreview.generated.json"
    assert json.loads(frontend_fixture.read_text()) == PREVIEW_CONTRACT


def test_report_timeline_emits_the_public_fixture_fields_in_site_time():
    expected = PREVIEW_CONTRACT["timeline_event"]
    event = make_event(occurred_at=datetime.fromisoformat(expected["occurred_at"]), direction=AccessDirection.ENTRY,
                       registration_number=expected["registration_number"])
    event.id = uuid.UUID(expected["id"])
    assert reports_service.serialize_timeline_event(event, timezone=reports_service._timezone("Europe/London")) == expected


def _legacy_duration_lookup(events, history, timezone):
    """Frozen pre-refactor policy oracle; intentionally inefficient."""
    result = {}
    history = sorted((event for event in history if duration_service.is_movement_event(event)), key=lambda event: event.occurred_at)
    for event in events:
        if not duration_service.is_movement_event(event):
            result[str(event.id)] = {"label": "N/A", "tone": "muted"}
            continue
        before = [prior for prior in history if prior.occurred_at < event.occurred_at]
        entry = event.direction == AccessDirection.ENTRY
        if entry:
            before = [prior for prior in before if duration_service.normalize_plate(prior.registration_number) == duration_service.normalize_plate(event.registration_number)]
        arrival = next((prior for prior in reversed(before) if prior.direction == AccessDirection.ENTRY), None)
        departure = next((prior for prior in reversed(before) if prior.direction == AccessDirection.EXIT), None)
        if arrival is None:
            result[str(event.id)] = {"label": "New Arrival", "tone": "new"} if entry else {"label": "No arrival found", "tone": "muted"}
        elif departure is not None and departure.occurred_at > arrival.occurred_at:
            result[str(event.id)] = duration_service.format_duration_info(departure.occurred_at, event.occurred_at, "Time since this vehicle was last on site", timezone=timezone) if entry else {"label": "No active visit", "tone": "muted"}
        else:
            result[str(event.id)] = {"label": "No prior departure", "tone": "muted"} if entry else duration_service.format_duration_info(arrival.occurred_at, event.occurred_at, "Time on site since last arrival", timezone=timezone)
    return result


def test_duration_pass_matches_original_policy_with_equal_times_and_cross_vehicle_history():
    import random

    randomizer = random.Random(4207)
    start = datetime(2026, 10, 25, 0, 30, tzinfo=UTC)
    history = [make_event(
        occurred_at=start + timedelta(minutes=index // 3),
        direction=randomizer.choice([AccessDirection.ENTRY, AccessDirection.EXIT, AccessDirection.DENIED]),
        decision=randomizer.choice([AccessDecision.GRANTED, AccessDecision.GRANTED, AccessDecision.DENIED]),
        registration_number=randomizer.choice(["AB12 CDE", "ab-12-cde", "XY34 ZZZ", "other"]),
    ) for index in range(600)]
    events = history[300:]
    randomizer.shuffle(events)
    timezone = reports_service._timezone("Europe/London")
    assert duration_service.build_duration_lookup(events, history, timezone=timezone) == _legacy_duration_lookup(events, history, timezone)


def test_bounded_predecessors_produce_same_durations_as_full_history():
    start = datetime(2026, 5, 1, tzinfo=UTC)
    history = [make_event(
        occurred_at=start + timedelta(minutes=index // 2),
        direction=AccessDirection.ENTRY if index % 3 else AccessDirection.EXIT,
        registration_number=["ab-12-cde", "AB12 CDE", "XY34ZZZ"][index % 3],
    ) for index in range(1000)]
    period = history[-40:]
    prior = [event for event in history if event.occurred_at < period[0].occurred_at]
    seeds = {}
    for event in prior:
        seeds[(duration_service.normalize_plate(event.registration_number), event.direction)] = event
        seeds[("global", event.direction)] = event
    assert duration_service.build_duration_lookup(period, [*seeds.values(), *period], timezone=ZoneInfo("UTC")) == duration_service.build_duration_lookup(period, history, timezone=ZoneInfo("UTC"))


async def test_predecessor_query_is_strictly_prior_and_projects_bounded_state():
    from sqlalchemy.dialects import postgresql

    class FakeSession:
        def __init__(self):
            self.queries = []

        async def execute(self, query):
            self.queries.append(str(query.compile(dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True})))
            return SimpleNamespace(first=lambda: None) if len(self.queries) <= 2 else []

    session = FakeSession()
    assert await reports_service._load_duration_predecessors(
        session, selected_filter=AccessEvent.person_id == uuid.uuid4(),
        period_start=datetime(2026, 5, 1, tzinfo=UTC), plates={"AB12CDE"},
    ) == []
    assert len(session.queries) == 3
    assert all("occurred_at <" in query and "raw_payload" not in query for query in session.queries)
    assert all("LIMIT 1" in query for query in session.queries[:2])
    assert "DISTINCT ON" in session.queries[2]
    assert "AB12CDE" in session.queries[2]


@pytest.mark.parametrize("total", [10000, 10001])
async def test_preview_combines_all_three_activity_arrays_under_one_limit(monkeypatch, total):
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    start = datetime(2026, 7, 14, 8, tzinfo=UTC)
    events = [make_event(occurred_at=start + timedelta(minutes=index), direction=AccessDirection.ENTRY)
              for index in range(3333)]
    extra = [make_event(occurred_at=start, direction=AccessDirection.EXIT, registration_number="OTHER")
             for _ in range(total - 9999)]
    session = ReportReadSession([events, [], [*events, *extra]])
    async def preview():
        return await reports_service.preview_person_movement_report(
            session, person_id=report_person().id, period_start=start, period_end=start + timedelta(days=4),
            include_denied=False, include_snapshots=False, include_confidence=False,
        )
    if total == 10001:
        with pytest.raises(ReportLimitError, match="combined activity rows"):
            await preview()
    else:
        report = (await preview())["report"]
        assert len(report["events"]) + len(report["timeline"]["all"]) + len(report["timeline"]["selected"]) == 10000


@pytest.mark.parametrize("include_denied", [False, True])
async def test_preview_applies_denied_filter_before_activity_sentinel(monkeypatch, include_denied):
    monkeypatch.setattr(reports_service, "get_runtime_config", london_report_config)
    forbid_report_effects(monkeypatch)
    start = datetime(2026, 7, 14, 8, tzinfo=UTC)
    events = [make_event(occurred_at=start, direction=AccessDirection.ENTRY, decision=AccessDecision.DENIED)
              for _ in range(10001)]
    session = ReportReadSession([events, [], []])
    async def preview():
        return await reports_service.preview_person_movement_report(
            session, person_id=report_person().id, period_start=start, period_end=start + timedelta(hours=1),
            include_denied=include_denied, include_snapshots=False, include_confidence=False,
        )
    if include_denied:
        with pytest.raises(ReportLimitError, match="combined activity rows"):
            await preview()
    else:
        assert (await preview())["report"]["events"] == []
